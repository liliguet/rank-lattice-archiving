"""Attach a rank-lattice archive to a published algorithm as a passive collector.

The host's selection is left unchanged. After the run the archive holds the
candidates retained at resolution b=3 with cell-order pruning, the default
configuration of the paper, and ``reduce`` selects a display set of the size of
the host's population. Both are exactly invariant under any componentwise
strictly increasing recalibration of the objectives.
"""
from pymoo.optimize import minimize

from pdom.metrics import igd_plus_normalized
from pdom.problems import get_problem
from pdom.workflow import RankLatticeCollector, as_pymoo_problem, make_baseline, pop_size_for

prob = get_problem("maf7", 5)
N = pop_size_for(prob.M)
collector = RankLatticeCollector(b=3, refresh_every=20)
res = minimize(as_pymoo_problem(prob), make_baseline("nsga3", prob.M, N, seed=0),
               ("n_evals", 100_000), seed=0, verbose=False, callback=collector)

pf = prob.pareto_front()
A = collector.members()
D, _ = collector.reduce(N)
print(f"host population  {len(res.pop):5d} points  IGD+ {igd_plus_normalized(res.pop.get('F'), pf):.4f}")
print(f"collected set    {len(A):5d} points  IGD+ {igd_plus_normalized(A, pf):.4f}")
print(f"display set      {len(D):5d} points  IGD+ {igd_plus_normalized(D, pf):.4f}")
