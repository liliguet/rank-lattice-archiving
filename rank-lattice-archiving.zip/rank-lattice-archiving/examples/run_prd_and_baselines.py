"""Run the partition-relaxed algorithm and two baselines on MaF2 with M = 5."""
import numpy as np

from pdom.metrics import igd_plus_normalized
from pdom.problems import get_problem
from pdom.workflow import run_baseline, run_prd

prob = get_problem("maf2", 5)
pf = prob.pareto_front()
budget = 20_000

out = run_prd(prob, seed=0, max_fe=budget)              # rank-archive configuration
A = np.atleast_2d(np.array(list(out["archive"].members()), float))
print(f"{'Rank-archive PRD, population':<32} IGD+ {igd_plus_normalized(out['F'], pf):.4f}")
print(f"{'Rank-archive PRD, archive':<32} IGD+ {igd_plus_normalized(A, pf):.4f}  |A|={len(A)}")

for name in ("nsga3", "sdr"):
    F = run_baseline(name, prob, seed=0, max_fe=budget)
    print(f"{name:<32} IGD+ {igd_plus_normalized(F, pf):.4f}")
