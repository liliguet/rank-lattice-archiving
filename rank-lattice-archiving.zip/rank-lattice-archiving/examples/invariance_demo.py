"""The rank lattice returns the same set under a monotone recalibration.

A stream of points is presented twice to two archives, once as it is and once
after the componentwise strictly increasing map that cubes the odd objectives
and sends the even ones through log(1+v). The rank lattice keeps the same
points, whereas an affine grid fitted to the observed range does not. The map
is first checked for strict order on the recorded values, since a map
evaluated in floating point can merge two distinct values.
"""
import numpy as np

from pdom.archive import QuotientArchive
from pdom.partitions import RankGridPartition, UniformGridPartition
from pdom.recalibration import order_violations


def retained(F, partition):
    arc = QuotientArchive(partition.fit(F), mode="S")
    for i, f in enumerate(F):
        arc.submit(f, data=i, ident=i)
    return sorted(arc.rep_data.values())


rng = np.random.default_rng(0)
t = rng.random((2000, 1))
F = np.hstack([t, 1 - np.sqrt(t), rng.random((2000, 3))]) + 0.05   # M = 5
G = F.copy()
G[:, 0::2] = G[:, 0::2] ** 3
G[:, 1::2] = np.log1p(G[:, 1::2])
print("order violations of the map per objective:", order_violations(F, G))

for name, make in [("rank lattice (b=3)", lambda: RankGridPartition(b=3)),
                   ("affine grid (K=8)", lambda: UniformGridPartition(K=8))]:
    a, b = retained(F, make()), retained(G, make())
    jac = len(set(a) & set(b)) / len(set(a) | set(b))
    print(f"{name:<20} |A|={len(a):4d}  same set: {a == b}  Jaccard {jac:.3f}")
