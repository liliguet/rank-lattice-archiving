"""
SDR (Strengthened Dominance Relation) baseline for pymoo.

Faithful port of the PlatEMO MATLAB implementation of NSGA-II/SDR:
    Y. Tian, R. Cheng, X. Zhang, Y. Su, and Y. Jin, "A Strengthened Dominance
    Relation Considering Convergence and Diversity for Evolutionary
    Many-Objective Optimization," IEEE TEVC, 23(2):331-345, 2019.

Reference MATLAB (PlatEMO): NSGAIISDR.m / NDSort_SDR.m / EnvironmentalSelection.m

SDR does not transform the objectives. It replaces the dominance relation itself
by a rule on convergence and angle that cannot be written as a transformation of
F, so it needs its own nondominated sorting and Survival operator. It is built on
NSGA-II (crowding distance), as in the original paper and in PlatEMO.

Correspondence notes vs. the MATLAB source, verified line by line:
  * MATLAB `cosine = 1 - pdist2(PopObj,PopObj,'cosine')` recovers cosine
    similarity; scipy `cdist(...,'cosine')` also returns (1 - cos), so we use
    `cosine_sim = 1 - cdist(F, F, 'cosine')`.
  * MATLAB `NormP = sum(PopObj,2)` is the L1 convergence measure (objectives are
    non-negative after the ideal-point shift; see normalization below).
  * `minA` is the ceil(N/2)-th smallest value of the per-solution minimum angle
    (a robust niche radius), computed over the set of *unique* minimum angles,
    exactly as in the MATLAB `temp = sort(unique(min(Angle,[],2)))`.
  * `Theta = max(1, (Angle./minA).^E)` with E = 1 in this PlatEMO version. The
    exponent is exposed as a parameter (`theta_exponent`) but defaults to 1.0 to
    reproduce the shipped behaviour.
  * Environmental normalization mirrors EnvironmentalSelection.m: shift by zmin,
    and divide by the range only when `0.05*max(range) < min(range)` (the same
    degenerate-range guard PlatEMO uses to avoid amplifying flat objectives).
"""

import numpy as np
from scipy.spatial.distance import cdist

from pymoo.algorithms.moo.nsga2 import NSGA2, binary_tournament
from pymoo.core.survival import Survival
from pymoo.operators.selection.tournament import TournamentSelection
from pymoo.operators.crossover.sbx import SBX
from pymoo.operators.mutation.pm import PM
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.operators.survival.rank_and_crowding.metrics import get_crowding_function


# ---------------------------------------------------------------------------
# Core SDR non-dominated sorting (port of NDSort_SDR.m)
# ---------------------------------------------------------------------------
def sdr_non_dominated_sorting(F_norm: np.ndarray,
                              n_sort: int,
                              theta_exponent: float = 1.0):
    """Non-dominated sorting under the Strengthened Dominance Relation.

    Parameters
    ----------
    F_norm : (N, M) array
        Objective values already shifted to the ideal point (non-negative),
        and range-normalized following the PlatEMO guard.
    n_sort : int
        Number of solutions that must receive a finite front number (PlatEMO
        stops assigning fronts once `n_sort` solutions are ranked).
    theta_exponent : float
        The exponent E in Theta = max(1, (Angle/minA)^E). E = 1 reproduces the
        shipped PlatEMO NSGA-II/SDR behaviour.

    Returns
    -------
    front_no : (N,) int array
        Front index per solution (1-based); unranked solutions get MaxFNo+? =
        the value `max_fno + 1` is NOT assigned here — unranked solutions keep
        a large sentinel so that `front_no < max_fno` deselects them, exactly as
        MATLAB uses `FrontNo < MaxFNo`.
    max_fno : int
        The last front index that was (partially) filled.
    """
    N = F_norm.shape[0]
    if N == 0:
        return np.zeros(0, dtype=int), 0

    # Convergence measure: L1 norm (sum of shifted objectives).
    norm_p = np.sum(F_norm, axis=1)

    # Pairwise angles between objective vectors.
    # scipy cdist 'cosine' == 1 - cosine_similarity, so similarity = 1 - that.
    cosine_sim = 1.0 - cdist(F_norm, F_norm, metric="cosine")
    np.fill_diagonal(cosine_sim, 0.0)                       # MATLAB zeroes diag
    cosine_sim = np.clip(cosine_sim, -1.0, 1.0)             # numerical safety
    angle = np.arccos(cosine_sim)

    # Adaptive niche radius minA: ceil(N/2)-th smallest *unique* per-row min angle.
    row_min_angle = np.min(angle, axis=1)
    uniq_sorted = np.unique(row_min_angle)                  # sorted ascending
    idx = min(int(np.ceil(N / 2.0)), uniq_sorted.shape[0]) - 1
    idx = max(idx, 0)
    min_a = uniq_sorted[idx]
    if min_a <= 0:
        # Degenerate: all solutions collinear. Fall back to a tiny positive value
        # so Theta reduces to 1 everywhere (pure convergence sorting).
        min_a = np.finfo(float).eps

    # Theta(i,j) = max(1, (Angle/minA)^E); neighbours (angle < minA) -> Theta = 1.
    theta = np.maximum(1.0, (angle / min_a) ** theta_exponent)

    # Strengthened dominance: i dominates j iff norm_p[i]*Theta[i,j] < norm_p[j].
    # Vectorized construction of the dominance matrix.
    lhs = norm_p[:, None] * theta                          # norm_p[i] * Theta[i,j]
    dominate = lhs < norm_p[None, :]                       # (i dominates j)
    np.fill_diagonal(dominate, False)

    # Front extraction identical in spirit to MATLAB while-loop.
    front_no = np.full(N, np.inf)
    max_fno = 0
    n_ranked = 0
    target = min(n_sort, N)
    # `dominated_by` counts, per column j, how many current-pool solutions
    # dominate j. A solution is in the current front iff no *remaining* solution
    # dominates it. We emulate the MATLAB pattern of clearing dominated rows.
    active_dominate = dominate.copy()
    while n_ranked < target:
        max_fno += 1
        # current front: solutions not dominated by anyone still active, and not
        # yet ranked.
        dominated_by_any = np.any(active_dominate, axis=0)
        current = (~dominated_by_any) & np.isinf(front_no)
        if not np.any(current):
            # Safety valve (should not happen for well-formed inputs): rank the
            # remaining best-converged solutions to guarantee termination.
            remaining = np.where(np.isinf(front_no))[0]
            order = remaining[np.argsort(norm_p[remaining])]
            need = target - n_ranked
            front_no[order[:need]] = max_fno
            n_ranked += min(need, order.shape[0])
            break
        front_no[current] = max_fno
        n_ranked += int(np.sum(current))
        # Remove the dominance influence of the just-ranked solutions.
        active_dominate[current, :] = False

    return front_no, max_fno


# ---------------------------------------------------------------------------
# SDR environmental selection (port of EnvironmentalSelection.m)
# ---------------------------------------------------------------------------
class SDRSurvival(Survival):
    """Environmental selection using SDR sorting + NSGA-II crowding distance.

    Mirrors PlatEMO's EnvironmentalSelection.m:
      1. shift objectives by the ideal point (zmin) and range-normalize under the
         `0.05*max(range) < min(range)` guard;
      2. deduplicate on 6-decimal-rounded objectives;
      3. SDR non-dominated sorting to obtain front numbers;
      4. keep all fronts below the last, then fill the last front by descending
         crowding distance.

    zmin/zmax are recomputed each generation from the merged population (matching
    the MATLAB main loop, which sets zmin over all objectives and zmax over the
    first front), so this Survival is self-contained and needs no external state.
    """

    def __init__(self, theta_exponent: float = 1.0, use_first_front_nadir: bool = True):
        super().__init__(filter_infeasible=True)
        self.theta_exponent = theta_exponent
        self.use_first_front_nadir = use_first_front_nadir
        self._crowding = get_crowding_function("cd")

    def _normalize(self, F, zmin, zmax):
        shifted = F - zmin
        rng = zmax - zmin
        # PlatEMO guard: only divide by range if no objective is nearly flat.
        if rng.size > 0 and (0.05 * np.max(rng) < np.min(rng)):
            with np.errstate(divide="ignore", invalid="ignore"):
                shifted = shifted / rng
        return shifted

    def _do(self, problem, pop, *args, n_survive=None, **kwargs):
        F = pop.get("F").astype(float)
        N_in = len(pop)
        if n_survive is None:
            n_survive = N_in

        # --- ideal / nadir estimation (recomputed per call) ---
        zmin = np.min(F, axis=0)
        if self.use_first_front_nadir:
            # MATLAB uses zmax = max over the current first Pareto front. We
            # approximate the first front by standard Pareto non-dominated set to
            # seed the nadir; falls back to global max if the set is degenerate.
            from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
            nd = NonDominatedSorting().do(F, only_non_dominated_front=True)
            zmax = np.max(F[nd], axis=0) if nd.size > 0 else np.max(F, axis=0)
        else:
            zmax = np.max(F, axis=0)
        # Guard against zmax <= zmin on any axis.
        zmax = np.where(zmax > zmin, zmax, zmin + 1e-12)

        PopObj = self._normalize(F, zmin, zmax)

        # --- deduplicate on 6-decimal rounding (MATLAB unique(round(*1e6)/1e6)) ---
        rounded = np.round(PopObj * 1e6) / 1e6
        _, keep_idx = np.unique(rounded, axis=0, return_index=True)
        keep_idx = np.sort(keep_idx)
        PopObj_u = PopObj[keep_idx]
        pop_u = pop[keep_idx]
        n_survive_eff = min(n_survive, len(pop_u))

        # --- SDR non-dominated sorting ---
        front_no, max_fno = sdr_non_dominated_sorting(
            PopObj_u, n_survive_eff, theta_exponent=self.theta_exponent
        )

        # --- crowding distance on normalized objectives (front-wise) ---
        crowd = self._crowding_distance_per_front(PopObj_u, front_no, max_fno)

        # --- select: all fronts below the last, then fill last by crowding ---
        next_mask = front_no < max_fno
        last = np.where(front_no == max_fno)[0]
        n_fill = n_survive_eff - int(np.sum(next_mask))
        if n_fill > 0 and last.size > 0:
            order = last[np.argsort(-crowd[last])]          # descending crowding
            next_mask[order[:n_fill]] = True

        survivors = pop_u[next_mask]
        # Attach rank/crowding so NSGA-II mating (rank, -crowding) works.
        survivors.set("rank", front_no[next_mask].astype(int))
        survivors.set("crowding", crowd[next_mask])
        return survivors

    def _crowding_distance_per_front(self, F, front_no, max_fno):
        crowd = np.zeros(F.shape[0])
        for f in range(1, max_fno + 1):
            idx = np.where(front_no == f)[0]
            if idx.size == 0:
                continue
            crowd[idx] = self._crowding.do(F[idx])
        return crowd


# ---------------------------------------------------------------------------
# Assembled algorithm
# ---------------------------------------------------------------------------
class SDR_NSGA2(NSGA2):
    """NSGA-II with the Strengthened Dominance Relation (Tian et al., 2019).

    Built on NSGA-II as in the original paper and PlatEMO. SDR is not
    decomposition-based, so a `ref_dirs` keyword is accepted and ignored, which
    keeps the call site uniform across baselines.
    """

    def __init__(self,
                 pop_size: int = 100,
                 theta_exponent: float = 1.0,
                 ref_dirs=None,                 # accepted & ignored for a uniform API
                 sampling=FloatRandomSampling(),
                 crossover=SBX(eta=30, prob=1.0),
                 mutation=PM(eta=20),
                 eliminate_duplicates=True,
                 **kwargs):
        selection = TournamentSelection(func_comp=binary_tournament)
        survival = SDRSurvival(theta_exponent=theta_exponent)
        super().__init__(
            pop_size=pop_size,
            sampling=sampling,
            selection=selection,
            crossover=crossover,
            mutation=mutation,
            survival=survival,
            eliminate_duplicates=eliminate_duplicates,
            **kwargs,
        )
        self.theta_exponent = theta_exponent


def make_sdr(pop_size: int, ref_dirs=None, theta_exponent: float = 1.0, **kwargs):
    """Factory mirroring the style of the other baseline constructors."""
    return SDR_NSGA2(pop_size=pop_size, theta_exponent=theta_exponent, **kwargs)
