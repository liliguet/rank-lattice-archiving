# -*- coding: utf-8 -*-
"""GrEA (grid-based evolutionary algorithm), ported line by line from PlatEMO.

    S. Yang, M. Li, X. Liu, J. Zheng, "A grid-based evolutionary algorithm for
    many-objective optimization," IEEE TEVC, 17(5): 721-736, 2013.

Reference implementation: PlatEMO GrEA.m, EnvironmentalSelection.m and
MatingSelection.m. As in the source,
  1. div is taken from the table Div = [0 45 15 10 9 9 8 8 10 12] by the
     number of objectives;
  2. the environmental selection propagates the GR penalty (the nested PD
     update);
  3. mating uses the binary tournament on grid dominance and GCD.
The grid is extended by half a cell on each side, lb = fmin - (fmax-fmin)/2/div,
so that extreme points do not lie on the boundary. Comments in the functions
give the correspondence with the source. All randomness is drawn from one
generator created from the seed.
"""
from __future__ import annotations

import numpy as np

from .algorithm import sbx_crossover, poly_mutation, nondominated_sort

# GrEA.m: Div = [0 45 15 10 9 9 8 8 10 12]; div = Div(min(M,10))
_DIV_TABLE = [0, 45, 15, 10, 9, 9, 8, 8, 10, 12]


def _div_for(M: int) -> int:
    return _DIV_TABLE[min(M, 10) - 1]


def _grid_setup(PopObj, div):
    """Grid location GLoc, grid ranking GR, grid coordinate point distance GCPD, grid difference GD and grid dominance G."""
    N, M = PopObj.shape
    fmax, fmin = PopObj.max(axis=0), PopObj.min(axis=0)
    span = fmax - fmin
    lb = fmin - span / 2.0 / div            # half-cell extension, as in the source
    ub = fmax + span / 2.0 / div
    d = np.maximum((ub - lb) / div, 1e-300)
    GLoc = np.floor((PopObj - lb) / d)
    GLoc[np.isnan(GLoc)] = 0
    GR = GLoc.sum(axis=1)
    GCPD = np.sqrt((((PopObj - (lb + GLoc * d)) / d) ** 2).sum(axis=1))
    # GD(i,j) = sum |GLoc_i - GLoc_j|, inf on the diagonal (source: GD = inf(N))
    GD = np.abs(GLoc[:, None, :] - GLoc[None, :, :]).sum(axis=2).astype(float)
    np.fill_diagonal(GD, np.inf)
    # grid dominance: k = any(GLoc_i<GLoc_j) - any(GLoc_i>GLoc_j)
    lt = (GLoc[:, None, :] < GLoc[None, :, :]).any(axis=2)
    gt = (GLoc[:, None, :] > GLoc[None, :, :]).any(axis=2)
    G = lt & ~gt
    np.fill_diagonal(G, False)
    return GLoc, GR, GCPD, GD, G


def grea_last_selection(PopObj, K, div):
    """LastSelection: choose K members of the last front by the grid measures."""
    N, M = PopObj.shape
    if K <= 0:
        return np.zeros(N, dtype=bool)
    if K >= N:
        return np.ones(N, dtype=bool)
    GLoc, GR, GCPD, GD, G = _grid_setup(PopObj, div)
    GR = GR.astype(float).copy()
    GCD = np.zeros(N)
    Remain = np.ones(N, dtype=bool)

    while Remain.sum() > N - K:
        cand = np.where(Remain)[0]
        # smallest GR, then smallest GCD, then smallest GCPD
        t1 = cand[GR[cand] == GR[cand].min()]
        t2 = t1[GCD[t1] == GCD[t1].min()]
        q = int(t2[np.argmin(GCPD[t2])])
        Remain[q] = False

        # GCD update: GCD += max(M - GD(q,:), 0)
        GCD = GCD + np.maximum(M - GD[q, :], 0)

        # GR update
        Eq = (GD[q, :] == 0) & Remain          # same grid cell
        Gq = G[q, :] & Remain                  # grid-dominated by q
        NGq = Remain & ~Gq
        Nq = (GD[q, :] < M) & Remain           # grid neighbours of q
        GR[Eq] += M + 2
        GR[Gq] += M

        # PD penalty propagation (the nested loop of the source)
        PD = np.zeros(N)
        targets = np.where(Nq & NGq & ~Eq)[0]
        for p in targets:
            if PD[p] < M - GD[q, p]:
                PD[p] = M - GD[q, p]
                Gp = G[p, :] & Remain
                for r in np.where(Gp & ~(Gq | Eq))[0]:
                    if PD[r] < PD[p]:
                        PD[r] = PD[p]
        pp = NGq & ~Eq
        GR[pp] += PD[pp]

    return ~Remain


def grea_survival(F, N, div=None):
    """EnvironmentalSelection: nondominated sorting and grid selection in the last front."""
    F = np.asarray(F, dtype=float)
    div = div or _div_for(F.shape[1])
    ranks = nondominated_sort(F)
    # MaxFNo: first front at which the cumulative count reaches N
    order = np.argsort(ranks, kind="stable")
    cum, max_f = 0, int(ranks.max())
    for f in range(int(ranks.min()), int(ranks.max()) + 1):
        cum += int((ranks == f).sum())
        if cum >= N:
            max_f = f
            break
    Next = ranks < max_f
    last = np.where(ranks == max_f)[0]
    K = N - int(Next.sum())
    if K > 0 and last.size > 0:
        choose = grea_last_selection(F[last], K, div)
        Next[last[choose]] = True
    sel = np.where(Next)[0]
    if len(sel) > N:
        sel = sel[:N]
    return list(sel)


def grea_mating_selection(F, div=None, rng=None):
    """MatingSelection.m: binary tournament on grid dominance, then smaller GCD,
    then at random. Pass the run's generator as ``rng``."""
    F = np.asarray(F, dtype=float)
    N = F.shape[0]
    div = div or _div_for(F.shape[1])
    _, GR, GCPD, GD, G = _grid_setup(F, div)
    M = F.shape[1]
    GCD = np.array([np.maximum(M - GD[i, :], 0).sum() for i in range(N)])
    rng = np.random.default_rng() if rng is None else rng
    pool = []
    for _ in range(N):
        a, b = rng.integers(0, N), rng.integers(0, N)
        if G[a, b]:
            pool.append(a)
        elif G[b, a]:
            pool.append(b)
        elif GCD[a] != GCD[b]:
            pool.append(a if GCD[a] < GCD[b] else b)
        else:
            pool.append(a if rng.random() < 0.5 else b)
    return pool


def run_grea(problem, N, max_fe, seed):
    """Main loop of GrEA.m. Returns the objective vectors of the final population."""
    rng = np.random.default_rng(seed)
    div = _div_for(problem.M)
    X = rng.uniform(problem.lo, problem.hi, size=(N, problem.n_var))
    F = problem.evaluate(X)
    fe = N
    while fe < max_fe:
        pool = grea_mating_selection(F, div, rng)
        P = X[pool]
        kids = []
        for i in range(0, len(P) - 1, 2):
            c1, c2 = sbx_crossover(P[i], P[i + 1], problem.lo, problem.hi, rng=rng)
            kids.append(poly_mutation(c1, problem.lo, problem.hi, rng=rng))
            kids.append(poly_mutation(c2, problem.lo, problem.hi, rng=rng))
        CX = np.array(kids[:N])
        CF = problem.evaluate(CX)
        fe += len(CX)
        AX, AF = np.vstack([X, CX]), np.vstack([F, CF])
        sel = grea_survival(AF, N, div)
        X, F = AX[sel], AF[sel]
    return F


def run_grea_X(problem, N, max_fe, seed):
    """As run_grea, returning the decision vectors, so that the population can be re-evaluated on the base problem."""
    rng = np.random.default_rng(seed)
    div = _div_for(problem.M)
    X = rng.uniform(problem.lo, problem.hi, size=(N, problem.n_var))
    F = problem.evaluate(X)
    fe = N
    while fe < max_fe:
        pool = grea_mating_selection(F, div, rng)
        P = X[pool]
        kids = []
        for i in range(0, len(P) - 1, 2):
            c1, c2 = sbx_crossover(P[i], P[i + 1], problem.lo, problem.hi, rng=rng)
            kids.append(poly_mutation(c1, problem.lo, problem.hi, rng=rng))
            kids.append(poly_mutation(c2, problem.lo, problem.hi, rng=rng))
        CX = np.array(kids[:N])
        CF = problem.evaluate(CX)
        fe += len(CX)
        AX, AF = np.vstack([X, CX]), np.vstack([F, CF])
        sel = grea_survival(AF, N, div)
        X, F = AX[sel], AF[sel]
    return X
