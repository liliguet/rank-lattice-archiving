# -*- coding: utf-8 -*-
"""θ-DEA, ported line by line from PlatEMO.

    Y. Yuan, H. Xu, B. Wang, X. Yao, "A new dominance relation-based evolutionary
    algorithm for many-objective optimization," IEEE TEVC, 20(1): 16-37, 2016.

Reference implementation: PlatEMO tDEA.m, EnvironmentalSelection.m and
Normalization.m. As in the source,
  1. the nadir point is estimated from ASF extreme points and the intercepts of
     their hyperplane;
  2. clusters are formed by the smallest perpendicular distance d2;
  3. theta is 1e6 for axis directions (a single significant weight) and 5
     otherwise, so that boundary directions are sorted by d1 alone.
"""
from __future__ import annotations

import numpy as np

from .algorithm import sbx_crossover, poly_mutation, nondominated_sort


def normalization(PopObj, z, znad):
    """Normalization.m: update the ideal and nadir points and normalize."""
    N, M = PopObj.shape
    z = np.minimum(z, PopObj.min(axis=0))
    # ASF extreme points
    W = np.full((M, M), 1e-6)
    np.fill_diagonal(W, 1.0)
    denom = np.maximum(znad - z, 1e-12)
    ASF = np.empty((N, M))
    for i in range(M):
        ASF[:, i] = np.max(np.abs((PopObj - z) / denom) / W[i], axis=1)
    extreme = np.argmin(ASF, axis=0)
    # hyperplane intercepts
    # MATLAB's A\b solves a nonsingular square system by LU, as np.linalg.solve
    # does. Where the system is singular or the intercepts are not finite or not
    # above z, the source falls back to the population maximum, and so does this port.
    with np.errstate(divide="ignore", invalid="ignore"):
        try:
            A = PopObj[extreme] - z
            hyper = np.linalg.solve(A, np.ones(M))
            a = 1.0 / hyper + z
            if np.any(~np.isfinite(a)) or np.any(a <= z):
                a = PopObj.max(axis=0)
        except np.linalg.LinAlgError:
            a = PopObj.max(axis=0)
    znad = a
    return (PopObj - z) / np.maximum(znad - z, 1e-12), z, znad


def t_nd_sort(PopObj, W):
    """tNDSort: theta-nondominated sorting."""
    N, NW = PopObj.shape[0], W.shape[0]
    normP = np.sqrt((PopObj ** 2).sum(axis=1))
    Wn = W / np.maximum(np.linalg.norm(W, axis=1, keepdims=True), 1e-12)
    Pn = PopObj / np.maximum(normP[:, None], 1e-12)
    Cosine = np.clip(Pn @ Wn.T, -1.0, 1.0)
    d1 = normP[:, None] * Cosine
    d2 = normP[:, None] * np.sqrt(np.maximum(1 - Cosine ** 2, 0.0))
    cls = np.argmin(d2, axis=1)
    # theta = 1e6 on axis directions and 5 elsewhere, as in the source
    theta = np.full(NW, 5.0)
    theta[(W > 1e-4).sum(axis=1) == 1] = 1e6
    tFrontNo = np.zeros(N, dtype=float)
    for i in range(NW):
        C = np.where(cls == i)[0]
        if C.size == 0:
            continue
        order = C[np.argsort(d1[C, i] + theta[i] * d2[C, i])]
        tFrontNo[order] = np.arange(1, C.size + 1)
    return tFrontNo


def theta_dea_survival(F, N, W, z, znad, rng):
    """EnvironmentalSelection.m. Returns the selected indices and the updated z and znad."""
    ranks = nondominated_sort(F)
    cum, max_f = 0, int(ranks.max())
    for f in range(int(ranks.min()), int(ranks.max()) + 1):
        cum += int((ranks == f).sum())
        if cum >= N:
            max_f = f
            break
    St = np.where(ranks <= max_f)[0]
    PopObj, z, znad = normalization(F[St], z, znad)
    tF = t_nd_sort(PopObj, W)
    # first theta-front at which the cumulative count reaches N
    counts = np.bincount(tF.astype(int), minlength=int(tF.max()) + 1)
    cum, maxF = 0, int(tF.max())
    for f in range(1, int(tF.max()) + 1):
        cum += counts[f]
        if cum >= N:
            maxF = f
            break
    last = np.where(tF == maxF)[0]
    rng.shuffle(last)
    excess = int((tF <= maxF).sum()) - N
    if excess > 0:
        tF[last[:excess]] = np.inf
    sel = St[tF <= maxF]
    return list(sel[:N]), z, znad


def run_theta_dea(problem, N, max_fe, seed, ref_dirs):
    """Main loop of tDEA.m. Returns the objective vectors of the final population."""
    rng = np.random.default_rng(seed)
    W = np.asarray(ref_dirs, dtype=float)
    X = rng.uniform(problem.lo, problem.hi, size=(N, problem.n_var))
    F = problem.evaluate(X)
    z, znad = F.min(axis=0), F.max(axis=0)
    fe = N
    while fe < max_fe:
        pool = rng.integers(0, N, size=N)        # source: randi, random mating
        P = X[pool]
        kids = []
        for i in range(0, len(P) - 1, 2):
            c1, c2 = sbx_crossover(P[i], P[i + 1], problem.lo, problem.hi, rng=rng)
            kids.append(poly_mutation(c1, problem.lo, problem.hi, rng=rng))
            kids.append(poly_mutation(c2, problem.lo, problem.hi, rng=rng))
        CX = np.array(kids[:N])
        CF = problem.evaluate(CX)
        fe += len(CX)
        AX, AF = np.vstack([X, CX]), np.vstack([F, CF])
        sel, z, znad = theta_dea_survival(AF, N, W, z, znad, rng)
        X, F = AX[sel], AF[sel]
    return F


def run_theta_dea_X(problem, N, max_fe, seed, ref_dirs):
    """As run_theta_dea, returning the decision vectors, so that the population can be re-evaluated on the base problem."""
    rng = np.random.default_rng(seed)
    W = np.asarray(ref_dirs, dtype=float)
    X = rng.uniform(problem.lo, problem.hi, size=(N, problem.n_var))
    F = problem.evaluate(X)
    z, znad = F.min(axis=0), F.max(axis=0)
    fe = N
    while fe < max_fe:
        pool = rng.integers(0, N, size=N)
        P = X[pool]
        kids = []
        for i in range(0, len(P) - 1, 2):
            c1, c2 = sbx_crossover(P[i], P[i + 1], problem.lo, problem.hi, rng=rng)
            kids.append(poly_mutation(c1, problem.lo, problem.hi, rng=rng))
            kids.append(poly_mutation(c2, problem.lo, problem.hi, rng=rng))
        CX = np.array(kids[:N])
        CF = problem.evaluate(CX)
        fe += len(CX)
        AX, AF = np.vstack([X, CX]), np.vstack([F, CF])
        sel, z, znad = theta_dea_survival(AF, N, W, z, znad, rng)
        X, F = AX[sel], AF[sel]
    return X
