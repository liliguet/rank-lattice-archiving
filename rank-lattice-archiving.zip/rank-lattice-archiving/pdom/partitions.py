# -*- coding: utf-8 -*-
"""Partitions of the objective space behind a common interface.

Interface
    fit(Y)            build the partition from reference data; the result is
                      a frozen realization (Remark 1 of the paper)
    assign(y)         cell identifier (hashable) of any point, including
                      points not seen at fit time
    orderable         True if the cell index carries the product order of an
                      order-sound partition (Definition 5); Mode tau and
                      cell-order pruning require it (Theorem 1)
    cell_key(cid)     integer tuple index on order-sound partitions, else None
    rank_invariant    True if assignment is invariant under componentwise
                      strictly increasing maps (Theorem 2)
    diameter_bound()  cell diameter delta in the partition's own metric, or
                      None if cells are unbounded
    depth_profile(y1, y2)  depth of the lowest common ancestor on tree
                      partitions, None elsewhere
    refresh(Y)        append Y to the reference set (refinement only); raises
                      NotImplementedError where unsupported

Partitions
    RankGridPartition    rank lattice, empirical-quantile cells (Definition 6)
    UniformGridPartition affine epsilon-lattice fitted to the observed range
    QLMPPartition        quantile Mondrian partition (Supplementary Material)
    MondrianPartition    Mondrian partition in objective values
    HilbertPartition     buckets of a Hilbert curve on normalized objectives
    RandomLSHPartition   random-projection hashing
    AnchorPartition      nearest Das-Dennis reference direction, as in NSGA-III
"""
from __future__ import annotations

import numpy as np
from abc import ABC, abstractmethod


class Partition(ABC):
    orderable: bool = False
    rank_invariant: bool = False
    name: str = "abstract"

    @abstractmethod
    def fit(self, Y: np.ndarray) -> "Partition":
        ...

    @abstractmethod
    def assign(self, y: np.ndarray):
        ...

    def cell_key(self, cid):
        return None

    def diameter_bound(self):
        return None

    def depth_profile(self, y1, y2):
        return None

    def refresh(self, Y: np.ndarray):
        raise NotImplementedError(f"{self.name} does not support refresh")

    def assign_batch(self, Y: np.ndarray):
        return [self.assign(y) for y in Y]


# ---------------------------------------------------------------- rank lattice
class RankGridPartition(Partition):
    """Rank lattice (Definition 6). The cell of y is (ceil(2^b F_j(y)))_j, where
    F_j is the empirical distribution function of objective j in the reference
    set. The index set is {0, ..., 2^b}^M and every cell has diameter at most
    2^-b in the rank metric.

      * F_j counts reference values that are <= y_j, so the cell of every point
        is unchanged by any componentwise strictly increasing map applied to
        both the reference set and the point.
      * refresh appends points to the reference set. The archive keeps its
        members in the cells in which they entered and is not refiltered.
    """
    orderable = True
    rank_invariant = True
    name = "rank_grid"

    def __init__(self, b: int = 5):
        self.b = int(b)
        self.K = 2 ** self.b
        self.ref = None

    def fit(self, Y):
        self.ref = np.array(Y, dtype=float, copy=True)
        # sorted columns, so that assign counts with searchsorted in O(log n)
        self._sorted = np.sort(self.ref, axis=0)
        return self

    def refresh(self, Y):
        self.ref = np.vstack([self.ref, np.asarray(Y, dtype=float)])
        self._sorted = np.sort(self.ref, axis=0)
        return self

    def Fhat(self, y):
        n = self._sorted.shape[0]
        return np.array([
            np.searchsorted(self._sorted[:, j], y[j], side="right") / n
            for j in range(self._sorted.shape[1])
        ])

    def assign(self, y):
        F = self.Fhat(np.asarray(y, dtype=float))
        idx = np.minimum(np.ceil(self.K * F).astype(np.int64), self.K)
        return tuple(int(v) for v in idx)

    def cell_key(self, cid):
        return cid

    def diameter_bound(self):
        return 1.0 / self.K  # in the rank metric


# ---------------------------------------------------------------- affine lattice
class UniformGridPartition(Partition):
    """Uniform epsilon-lattice in the line of Laumanns et al. (2002), with eps_j
    set from the range observed at fit time (K cells per axis), that is, an
    epsilon-lattice after an affine normalization. It is invariant under
    affine maps but not under nonlinear monotone maps."""
    orderable = True
    rank_invariant = False
    name = "uniform_grid"

    def __init__(self, K: int = 32, eps: float | None = None):
        self.K = int(K)
        self.eps_fixed = eps  # a scalar eps, if given, overrides K
        self.lo = None
        self.eps_vec = None

    def fit(self, Y):
        Y = np.asarray(Y, dtype=float)
        self.lo = Y.min(axis=0)
        if self.eps_fixed is not None:
            self.eps_vec = np.full(Y.shape[1], float(self.eps_fixed))
        else:
            self.eps_vec = np.maximum(Y.max(axis=0) - self.lo, 1e-12) / self.K
        return self

    def refresh(self, Y):
        # adaptive normalization: the lower bound is re-estimated, as in adaptive grids
        Y = np.asarray(Y, dtype=float)
        self.lo = np.minimum(self.lo, Y.min(axis=0))
        return self

    def assign(self, y):
        idx = np.floor((np.asarray(y, dtype=float) - self.lo) / self.eps_vec).astype(np.int64)
        return tuple(int(v) for v in idx)

    def cell_key(self, cid):
        return cid

    def diameter_bound(self):
        return float(np.max(self.eps_vec))  # in L_inf (largest eps_j)


# ---------------------------------------------------------------- Hilbert curve
def _hilbert_index(coords, bits):
    """Hilbert index of integer coordinates by Skilling's algorithm."""
    X = [int(c) for c in coords]
    n = len(X)
    Mbit = 1 << (bits - 1)
    q = Mbit
    while q > 1:
        p = q - 1
        for i in range(n):
            if X[i] & q:
                X[0] ^= p
            else:
                t = (X[0] ^ X[i]) & p
                X[0] ^= t
                X[i] ^= t
        q >>= 1
    for i in range(1, n):
        X[i] ^= X[i - 1]
    t = 0
    q = Mbit
    while q > 1:
        if X[n - 1] & q:
            t ^= q - 1
        q >>= 1
    for i in range(n):
        X[i] ^= t
    h = 0
    for bpos in range(bits - 1, -1, -1):
        for i in range(n):
            h = (h << 1) | ((X[i] >> bpos) & 1)
    return h


class HilbertPartition(Partition):
    """Buckets of a Hilbert curve, identified by the leading bits of the curve
    index. The index is totally ordered but carries no product order, so the
    partition is not order sound and cell-order pruning does not apply."""
    orderable = False
    rank_invariant = False
    name = "hilbert"

    def __init__(self, bits: int = 6, bucket_bits: int = 8):
        self.bits = int(bits)
        self.bucket_bits = int(bucket_bits)
        self.lo = None
        self.hi = None

    def fit(self, Y):
        Y = np.asarray(Y, dtype=float)
        self.lo = Y.min(axis=0)
        self.hi = Y.max(axis=0)
        self.M = Y.shape[1]
        return self

    def assign(self, y):
        y = np.asarray(y, dtype=float)
        span = np.maximum(self.hi - self.lo, 1e-12)
        u = np.clip((y - self.lo) / span, 0.0, 1.0 - 1e-12)
        coords = np.floor(u * (2 ** self.bits)).astype(np.int64)
        h = _hilbert_index(coords, self.bits)
        total_bits = self.M * self.bits
        shift = max(total_bits - self.bucket_bits, 0)
        return int(h >> shift)


# ---------------------------------------------------------------- random hashing
class RandomLSHPartition(Partition):
    """Random-projection hashing with bucket width ``width`` (Datar et al.,
    2004). Cells are unbounded, so there is no diameter bound."""
    orderable = False
    rank_invariant = False
    name = "random_lsh"

    def __init__(self, width: float = 0.5, n_hash: int | None = None,
                 seed: int = 0):
        # The number of cells is controlled by width (larger is coarser), which
        # is the calibrated parameter; n_hash defaults to min(M, 4), at least 2.
        self.width = float(width)
        self.n_hash = n_hash
        self.seed = int(seed)

    def fit(self, Y):
        Y = np.asarray(Y, dtype=float)
        rng = np.random.default_rng(self.seed)
        M = Y.shape[1]
        if self.n_hash is None:
            self.n_hash = max(2, min(M, 4))
        scale = np.maximum(Y.std(axis=0), 1e-12)
        self._A = rng.normal(size=(self.n_hash, M)) / scale
        self._b = rng.uniform(0, self.width, size=self.n_hash)
        return self

    def assign(self, y):
        v = (self._A @ np.asarray(y, dtype=float) + self._b) / self.width
        return tuple(int(x) for x in np.floor(v))


# ---------------------------------------------------------------- Mondrian
class MondrianPartition(Partition):
    """Mondrian partition in objective values with rate measure Lambda and
    collision kernel kappa = exp(-lam * sum_j Lambda_j |dy_j|)."""
    orderable = False
    rank_invariant = False
    name = "mondrian_lmp"

    def __init__(self, lam: float = 3.0, Lambda: np.ndarray | None = None, seed: int = 0):
        self.lam = float(lam)
        self.Lambda = Lambda
        self.seed = int(seed)
        self.cuts = []

    MAX_CUTS = 4096  # safety cap on the number of cuts

    def fit(self, Y):
        Y = np.asarray(Y, dtype=float)
        rng = np.random.default_rng(self.seed)
        lo = Y.min(axis=0) - 1e-9
        hi = Y.max(axis=0) + 1e-9
        if self.Lambda is None:
            # rate measure scaled by the data range, so that every axis has
            # cuts of the same expected intensity
            Lam = 1.0 / np.maximum(hi - lo, 1e-12)
        else:
            Lam = np.asarray(self.Lambda, float)
        self.cuts = []
        self._build(lo.copy(), hi.copy(), 0.0, Lam, rng)
        return self

    def _build(self, lo, hi, t, Lam, rng):
        if len(self.cuts) >= self.MAX_CUTS:
            return
        lengths = (hi - lo) * Lam
        total = lengths.sum()
        if total <= 0:
            return
        E = rng.exponential(1.0 / total)
        if t + E > self.lam:
            return
        ax = rng.choice(len(lo), p=lengths / total)
        thr = rng.uniform(lo[ax], hi[ax])
        self.cuts.append((int(ax), float(thr)))
        hi_l = hi.copy(); hi_l[ax] = thr
        lo_r = lo.copy(); lo_r[ax] = thr
        self._build(lo, hi_l, t + E, Lam, rng)
        self._build(lo_r, hi, t + E, Lam, rng)

    def assign(self, y):
        y = np.asarray(y, dtype=float)
        return tuple(int(y[ax] > thr) for ax, thr in self.cuts)

    def collision_kernel(self, y1, y2):
        Lam = np.ones(len(y1)) if self.Lambda is None else np.asarray(self.Lambda, float)
        return float(np.exp(-self.lam * np.sum(Lam * np.abs(np.asarray(y1) - np.asarray(y2)))))


# ---------------------------------------------------------------- quantile Mondrian
class QLMPPartition(Partition):
    """Quantile Mondrian partition (Supplementary Material). Thresholds are
    order statistics of the reference data themselves, so assignment depends
    only on comparisons with data values and is rank invariant. Coverage holds
    in the tree ultrametric."""
    orderable = False
    rank_invariant = True
    name = "qlmp"

    def __init__(self, depth: int = 6, m0: int = 8, q: float = 0.5,
                 axis_dist=None, seed: int = 0):
        self.depth = int(depth)
        self.m0 = int(m0)
        self.q = float(q)
        self.axis_dist = axis_dist  # optional distribution of the split axis
        self.seed = int(seed)
        self.tree = None

    def fit(self, Y):
        Y = np.asarray(Y, dtype=float)
        rng = np.random.default_rng(self.seed)
        self.tree = self._grow(Y, 0, rng)
        return self

    def _grow(self, S, d, rng):
        if d >= self.depth or S.shape[0] <= self.m0:
            return None  # leaf
        M = S.shape[1]
        if self.axis_dist is None:
            ax = int(rng.integers(M))
        else:
            p = np.asarray(self.axis_dist(S), dtype=float)
            ax = int(rng.choice(M, p=p / p.sum()))
        k = int(np.ceil(self.q * S.shape[0]))
        thr = float(np.sort(S[:, ax])[k - 1])  # the order statistic itself
        left_mask = S[:, ax] <= thr
        if left_mask.all() or (~left_mask).all():
            return None  # degenerate cut: stop
        return {
            "ax": ax, "thr": thr,
            "L": self._grow(S[left_mask], d + 1, rng),
            "R": self._grow(S[~left_mask], d + 1, rng),
        }

    def assign(self, y):
        y = np.asarray(y, dtype=float)
        node = self.tree
        path = []
        while node is not None:
            go_left = y[node["ax"]] <= node["thr"]
            path.append(0 if go_left else 1)
            node = node["L"] if go_left else node["R"]
        return tuple(path)

    def depth_profile(self, y1, y2):
        c1, c2 = self.assign(y1), self.assign(y2)
        lca = 0
        for a, b in zip(c1, c2):
            if a != b:
                break
            lca += 1
        return lca  # tree ultrametric rho_T = 2^-lca


# ------------------------------------------------------- nearest-anchor partition
class AnchorPartition(Partition):
    """Nearest-anchor partition, the partition implicit in the association step
    of NSGA-III. Anchors are Das-Dennis reference directions and a cell is the
    cone of points nearest to one direction after normalization."""
    orderable = False
    rank_invariant = False
    name = "anchor"

    MAX_DIRS = 20000   # cap on the number of directions

    def __init__(self, n_partitions: int = 6, max_dirs: int | None = None):
        self.H = int(n_partitions)
        self.max_dirs = int(max_dirs or self.MAX_DIRS)
        self.dirs = None

    @staticmethod
    def n_ref_points(M, H):
        from math import comb
        return comb(H + M - 1, M - 1)

    @staticmethod
    def _das_dennis(M, H):
        def rec(prefix, left, slots):
            if slots == 1:
                yield prefix + [left]
                return
            for v in range(left + 1):
                yield from rec(prefix + [v], left - v, slots - 1)
        W = np.array(list(rec([], H, M)), dtype=float) / H
        return np.maximum(W, 1e-9)

    def fit(self, Y):
        Y = np.asarray(Y, dtype=float)
        self.M = Y.shape[1]
        # The Das-Dennis count C(H+M-1, M-1) grows quickly with M (9.6e6 for
        # M=15, H=12). Above the cap the two-layer construction of NSGA-III is
        # used with the largest feasible H, and the set is thinned at random if
        # it still exceeds the cap.
        H = self.H
        while H > 1 and self.n_ref_points(self.M, H) > self.max_dirs:
            H -= 1
        W = self._das_dennis(self.M, H)
        if self.H > H:
            inner = self._das_dennis(self.M, max(H - 1, 1))
            inner = inner * 0.5 + (0.5 / self.M)
            W = np.vstack([W, inner])
        if len(W) > self.max_dirs:
            idx = np.random.default_rng(0).choice(len(W), self.max_dirs,
                                                  replace=False)
            W = W[idx]
        self.dirs = np.maximum(W, 1e-9)
        self.dirs /= np.linalg.norm(self.dirs, axis=1, keepdims=True)
        self.ideal = Y.min(axis=0)
        self.span = np.maximum(Y.max(axis=0) - self.ideal, 1e-12)
        return self

    def refresh(self, Y):
        # the ideal point and span are re-estimated, as in NSGA-III's normalization
        Y = np.asarray(Y, dtype=float)
        self.ideal = np.minimum(self.ideal, Y.min(axis=0))
        self.span = np.maximum(np.maximum(Y.max(axis=0), self.ideal + self.span) - self.ideal, 1e-12)
        return self

    def assign(self, y):
        f = (np.asarray(y, dtype=float) - self.ideal) / self.span  # reads magnitudes by design
        norm = np.linalg.norm(f) + 1e-12
        cosines = self.dirs @ (f / norm)
        d_perp = norm * np.sqrt(np.maximum(1.0 - cosines ** 2, 0.0))
        return int(np.argmin(d_perp))


BACKENDS = {
    "random_lsh": RandomLSHPartition,
    "hilbert": HilbertPartition,
    "rank_grid": RankGridPartition,
    "mondrian_lmp": MondrianPartition,
    "qlmp": QLMPPartition,
    "anchor": AnchorPartition,
    "uniform_grid": UniformGridPartition,
}
