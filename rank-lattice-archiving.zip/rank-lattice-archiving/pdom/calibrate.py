# -*- coding: utf-8 -*-
"""Calibration of every partition to a common number of occupied cells.

Each partition controls its number of cells through its own parameter (b, K,
bucket_bits, width, lam, depth, n_partitions). Comparing partitions without
calibration would compare numbers of cells rather than geometries. This module
scans each parameter over a grid of candidates and picks the value whose number
of occupied cells on a sample is closest, on a log scale, to a target.

Usage
    from pdom.calibrate import calibrate_backends, make_factory
    cfg = calibrate_backends(M=5, sample=F_pool, target_cells=100)
    factory = make_factory("rank_grid", cfg, seed=0)
"""
from __future__ import annotations

import json
import os

import numpy as np

from .partitions import (RankGridPartition, UniformGridPartition,
                         HilbertPartition, RandomLSHPartition,
                         MondrianPartition, QLMPPartition, AnchorPartition)

# (parameter, candidates) per partition, candidates in increasing number of cells
PARAM_GRID = {
    "rank_grid":    ("b", list(range(1, 9))),
    "uniform_grid": ("K", [2, 3, 4, 6, 8, 12, 16, 24, 32, 48, 64]),
    "hilbert":      ("bucket_bits", list(range(2, 16))),
    # width is decreasing (cells increasing); lam extends down to 0.01, since
    # coarser candidates are needed to reach the target at large M
    "random_lsh":   ("width", [40.0, 20.0, 10.0, 5.0, 3.0, 2.0, 1.2,
                               0.8, 0.5, 0.3, 0.2, 0.1]),
    # the number of Mondrian cells grows about exponentially in lam (from 1 to
    # 490 cells between 0.1 and 0.2 at M=15), so the grid is dense at the low end
    "mondrian_lmp": ("lam", [0.01, 0.02, 0.04, 0.06, 0.08, 0.10, 0.12, 0.14,
                             0.16, 0.18, 0.20, 0.25, 0.30, 0.40, 0.55, 0.70,
                             1.0, 1.5, 2.0, 3.0, 4.5, 6.0, 9.0]),
    "qlmp":         ("depth", list(range(1, 13))),
    "anchor":       ("n_partitions", list(range(1, 13))),
}

_CTORS = {
    "rank_grid": RankGridPartition,
    "uniform_grid": UniformGridPartition,
    "hilbert": HilbertPartition,
    "random_lsh": RandomLSHPartition,
    "mondrian_lmp": MondrianPartition,
    "qlmp": QLMPPartition,
    "anchor": AnchorPartition,
}


def _too_expensive(name, value, M):
    """True if a candidate is too expensive to build at this M."""
    if name == "anchor":
        from math import comb
        return comb(value + M - 1, M - 1) > 20000
    if name == "mondrian_lmp":
        return (1.0 + value) ** M > 2e5
    if name == "rank_grid":
        return value * M > 120          # index set of size 2^(bM) is pointless
    return False


def _build(name, value, seed=0):
    key, _ = PARAM_GRID[name]
    kwargs = {key: value}
    if name in ("random_lsh", "mondrian_lmp", "qlmp"):
        kwargs["seed"] = seed
    if name == "mondrian_lmp":
        kwargs.setdefault("Lambda", None)
    if name == "hilbert":
        kwargs.setdefault("bits", 6)
    if name == "qlmp":
        kwargs.setdefault("m0", 4)
    return _CTORS[name](**kwargs)


def occupied_cells(name, value, sample, seed=0):
    part = _build(name, value, seed).fit(sample)
    return len({part.assign(y) for y in sample}), part


def calibrate_backends(M, sample, target_cells, backends=None, seed=0,
                       verbose=False):
    """Parameter value of each partition closest to ``target_cells`` occupied cells, {name: value}."""
    sample = np.asarray(sample, dtype=float)
    backends = backends or list(PARAM_GRID)
    cfg = {}
    for name in backends:
        key, cands = PARAM_GRID[name]
        best, best_gap, best_n = cands[0], float("inf"), 0
        prev_n = -1
        stall = 0
        for v in cands:
            if _too_expensive(name, v, M):
                break                     # remaining candidates are too expensive
            try:
                n, _ = occupied_cells(name, v, sample, seed)
            except Exception:
                continue
            gap = abs(np.log(max(n, 1)) - np.log(target_cells))
            if gap < best_gap:
                best, best_gap, best_n = v, gap, n
            if n > target_cells * 4:
                break
            # the number of occupied cells saturates at the sample size (common
            # at large M); stop after two candidates without growth
            stall = stall + 1 if n <= prev_n else 0
            prev_n = n
            # but only once the target has been passed, since a plateau at the
            # coarse end (a single Mondrian cell for small lam) also shows no growth
            if n >= len(sample) * 0.98 or (stall >= 2 and n > target_cells):
                break
        cfg[name] = best
        if verbose:
            print(f"  {name:14s} {key}={best} -> {best_n} occupied cells "
                  f"(target {target_cells})")
    return cfg


def make_factory(name, cfg, seed=0):
    """Factory without arguments for the calibrated partition, as used by PRDEA."""
    return lambda: _build(name, cfg[name], seed)


def cache_path(root, M, target_cells, tag=None):
    stem = f"calib_M{M}_C{target_cells}" if tag is None else f"calib_{tag}_M{M}_C{target_cells}"
    return os.path.join(root, stem + ".json")


def load_or_calibrate(root, M, sample, target_cells, seed=0, verbose=False,
                      tag=None, backends=None):
    """Calibrate, with an optional cache on disk.

    With ``root=None`` the calibration is computed and not cached. Otherwise
    the result is cached under ``root`` by (tag, M, target_cells); the tag must
    identify the sample (for instance problem and seed), since a cached result
    is reused for any sample with the same key. The file is written to a
    temporary name and renamed, so that concurrent processes never read a
    partial file, and a file that cannot be read is recomputed.
    """
    if root is None:
        return calibrate_backends(M, sample, target_cells, backends=backends,
                                  seed=seed, verbose=verbose)
    path = cache_path(root, M, target_cells, tag)
    if os.path.exists(path):
        try:
            with open(path) as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass                          # partial or damaged: recompute
    cfg = calibrate_backends(M, sample, target_cells, backends=backends, seed=seed,
                             verbose=verbose)
    os.makedirs(root, exist_ok=True)
    tmp = f"{path}.{os.getpid()}.tmp"
    try:
        with open(tmp, "w") as f:
            json.dump(cfg, f, indent=2)
        os.replace(tmp, path)             # atomic rename in the same directory
    except OSError:
        pass
    finally:
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
    return cfg
