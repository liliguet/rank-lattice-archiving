"""
LEO (Learning-aided Evolutionary Optimization) baseline for pymoo, many-objective.

Faithful port of the OFFICIAL multi-objective LEO code supplied by the authors:
    Zhi-Hui Zhan, Jian-Yu Li, Sam Kwong, Jun Zhang, "Learning-aided Evolution for
    Optimization," IEEE TEVC, 2022, DOI:10.1109/TEVC.2022.3232776.
Reference (PlatEMO): LEO.m + mynetwork.m + EnvironmentalSelection.m (RVEA) +
ReferenceVectorAdaptation.m.

The authors' multi-objective LEO is built on RVEA and collects its training data
without any scalar fitness. The correspondence below is line for line with LEO.m.

------------------------------------------------------------------------------
How official multi-objective LEO works (LEO.m), and how we mirror it
------------------------------------------------------------------------------
Host: RVEA (UniformPoint reference vectors, APD-based environmental selection,
periodic reference-vector adaptation). pymoo's RVEA(alpha=2, adapt_freq=0.1)
reproduces PlatEMO's RVEA defaults, so we host LEO on it and leave selection +
adaptation to pymoo.

Per generation LEO.m does:
  lp = FE/maxFE * 0.5                      # RAMPS 0 -> 0.5 over the run
  if rand() < lp:                          # learned operator (rare early, common late)
      tempx = (decs - lb)/(ub-lb)          # normalize population to [0,1]
      lpop  = net.forward(tempx)           # predict (LINEAR output layer)
      lpop  = lpop.*(ub-lb) - lb           # denormalize (see note below)
      lpop  = lpop + 0.5*(decs[r2]-decs[r1])   # DE-style perturbation in RAW space
      Offspring = Evaluate(lpop)
  else:
      Offspring = OperatorGA(...)          # standard SBX+PM
  olddecs = population BEFORE selection
  Population = EnvironmentalSelection([Population, Offspring], V, (FE/maxFE)^alpha)
  newdecs = population AFTER selection
  # SEP: pair the pre-selection and post-selection populations BY INDEX, no
  # improvement test, no scalar fitness -- learn the selection-induced map:
  sep_x = (olddecs[1:nseps] - lb)/(ub-lb)
  sep_y = (newdecs[1:nseps] - lb)/(ub-lb)
  net = net.train(sep_x, sep_y)
  periodic reference-vector adaptation

Two faithful-to-source notes:
  * Denormalization in LEO.m is `lpop.*range - lb`. For DTLZ and WFG the lower
    bound is exactly 0, so `range - lb == range + lb`; the formula is therefore
    identical to the correct denormalization on every benchmark used here. We
    replicate LEO.m exactly (`- lb`); on xl=0 problems it equals `+ lb`.
  * The DE-style perturbation is added in RAW decision space using
    `decs[r2]-decs[r1]` (note the r2-r1 order and the raw, not normalized, decs).

The crucial many-objective design point: SEP pairs "population before selection"
with "population after selection" by index. RVEA's selection defines the
improvement direction, so LEO learns that map WITHOUT any scalar fitness -- which
is why this multi-objective LEO needs neither Tchebycheff nor a dominance test in
its learning signal.

Network (mynetwork.m): D -> 3D (sigmoid) -> D (LINEAR output), SGD, MSE,
lr=0.1 (the multi-objective mynetwork uses 0.1, not the 0.01 of the
single-objective version), 1 epoch/update, init randn/fan_out, bias 0.
"""

import numpy as np

from pymoo.algorithms.moo.rvea import RVEA
from pymoo.core.population import Population


class LEONetwork:
    """Two-layer MLP matching mynetwork.m exactly (D -> 3D sigmoid -> D linear)."""

    def __init__(self, n_in, n_out, n_hidden, lr=0.1, epochs=1, rng=None,
                 weight_cap=1e6):
        self.rng = rng if rng is not None else np.random.default_rng()
        self.lr = lr
        self.epochs = epochs
        self.weight_cap = weight_cap
        self.W1 = self.rng.standard_normal((n_in, n_hidden)) / n_hidden
        self.b1 = np.zeros((1, n_hidden))
        self.W2 = self.rng.standard_normal((n_hidden, n_out)) / n_out
        self.b2 = np.zeros((1, n_out))

    def forward(self, x):
        h = 1.0 / (1.0 + np.exp(-(x @ self.W1 + self.b1)))     # sigmoid hidden
        return h @ self.W2 + self.b2                            # linear output

    def train(self, x, y):
        n = x.shape[0]
        if n == 0:
            return
        eta = self.lr
        for _ in range(self.epochs):
            yh = 1.0 / (1.0 + np.exp(-(x @ self.W1 + self.b1)))
            z = yh @ self.W2 + self.b2
            sj = (z - y) / n                                   # output sensitivity
            dW2 = eta * (yh.T @ sj)
            db2 = eta * np.sum(sj, axis=0, keepdims=True)
            sh = -yh * (1.0 - yh) * (sj @ self.W2.T)           # hidden sensitivity
            dW1 = eta * (x.T @ sh)
            db1 = eta * np.sum(sh, axis=0, keepdims=True)
            self.W2 -= dW2
            self.b2 -= db2
            self.W1 -= dW1
            self.b1 -= db1
        # Numerical-hygiene safeguard (documented DEVIATION from LEO.m):
        # LEO.m's mynetwork (lr=0.1, randn/fan_out init, no regularization) can let
        # the weights diverge over a full run; in LEO.m this is cosmetic because the
        # operator output is clipped to bounds, diluted by the DE perturbation, and
        # filtered by RVEA selection, so the diverged network simply contributes
        # clipped noise. In double precision, however, an unchecked run overflows to
        # inf (RuntimeWarning in matmul), after which training becomes a no-op. We
        # therefore cap the weight norm to a large constant. This preserves LEO.m's
        # behavior wherever it is well-defined (the cap never binds until weights are
        # astronomically large, at which point the network was already contributing
        # only clipped noise) while preventing inf/nan. Set weight_cap=None to
        # reproduce LEO.m's raw (potentially overflowing) numerics exactly.
        if self.weight_cap is not None:
            for W in (self.W1, self.W2):
                nrm = np.linalg.norm(W)
                if nrm > self.weight_cap:
                    W *= self.weight_cap / nrm


class LEO_RVEA(RVEA):
    """RVEA augmented by the LEO learned operator, ported from official LEO.m."""

    def __init__(self, ref_dirs, pop_size=None, alpha=2.0, adapt_freq=0.1,
                 hidden_mult=3, lr=0.1, epochs=1, seed=None, **kwargs):
        super().__init__(ref_dirs=ref_dirs, alpha=alpha, adapt_freq=adapt_freq,
                         pop_size=pop_size, **kwargs)
        self._leo_cfg = dict(hidden_mult=hidden_mult, lr=lr, epochs=epochs)
        self._net = None
        self._rng = np.random.default_rng(seed)
        self._pre_selection_X = None

    def _ensure_net(self):
        if self._net is None:
            D = self.problem.n_var
            self._net = LEONetwork(D, D, self._leo_cfg["hidden_mult"] * D,
                                   lr=self._leo_cfg["lr"],
                                   epochs=self._leo_cfg["epochs"], rng=self._rng)

    def _lp(self):
        """lp = FE/maxFE * 0.5, as LEO.m; falls back to a generation ratio."""
        try:
            fe = self.evaluator.n_eval
            max_fe = getattr(self.termination, "n_max_evals", None)
            if max_fe:
                return (fe / max_fe) * 0.5
        except Exception:
            pass
        n_gen = self.n_gen or 1
        max_gen = getattr(self.termination, "n_max_gen", None) or 400
        return (n_gen / max_gen) * 0.5

    def _norm(self, X):
        xl, xu = self.problem.xl, self.problem.xu
        return (X - xl[None, :]) / (xu - xl)[None, :]

    def _denorm_leo(self, Xn):
        # LEO.m: lpop.*range - lb  (== +lb on xl=0 problems; replicated faithfully)
        xl, xu = self.problem.xl, self.problem.xu
        return Xn * (xu - xl)[None, :] - xl[None, :]

    def _infill(self):
        self._ensure_net()
        self._pre_selection_X = (self.pop.get("X").copy()
                                 if self.pop is not None else None)

        if self.pop is not None and self._rng.random() < self._lp():
            decs = self.pop.get("X")
            n = decs.shape[0]
            tempx = self._norm(decs)
            lpop = self._net.forward(tempx)
            lpop = self._denorm_leo(lpop)
            r1 = self._rng.integers(0, n, size=n)
            r2 = self._rng.integers(0, n, size=n)
            lpop = lpop + 0.5 * (decs[r2] - decs[r1])          # raw space, r2-r1
            lpop = np.clip(lpop, self.problem.xl[None, :], self.problem.xu[None, :])
            return Population.new(X=lpop)
        else:
            return super()._infill()

    def _advance(self, infills=None, **kwargs):
        out = super()._advance(infills=infills, **kwargs)
        if (self._pre_selection_X is not None and self.pop is not None
                and self._net is not None):
            olddecs = self._pre_selection_X
            newdecs = self.pop.get("X")
            nseps = min(olddecs.shape[0], newdecs.shape[0])
            if nseps > 0:
                self._net.train(self._norm(olddecs[:nseps]),
                                self._norm(newdecs[:nseps]))
        return out


def make_leo(ref_dirs, pop_size, **kwargs):
    """Factory mirroring the style of the other baseline constructors."""
    return LEO_RVEA(ref_dirs=ref_dirs, pop_size=pop_size, **kwargs)
