# -*- coding: utf-8 -*-
"""Reduction of a retained set to a display set of a given size.

The collector retains more points than a decision maker usually wants to look
at. ``dss`` reduces a set to ``k`` points by distance-based subset selection
(Singh et al., 2019), that is, farthest-point greedy selection started from the
point with the smallest coordinate sum. Two coordinate systems are available.

``coords="quantile"``  per-objective empirical quantiles (ranks divided by n,
                       ties sharing the upper rank). The selection then depends
                       only on the order of each objective, so the display set
                       inherits the exact invariance of the rank lattice.
``coords="normalized"`` min-max normalization of each objective. This is the
                       usual choice and reads magnitudes, so it is not
                       invariant under nonlinear recalibration.

Ties in the greedy steps are resolved by position, so the result is a
deterministic function of the input order.
"""
from __future__ import annotations

import numpy as np


def quantile_coords(F):
    """Empirical quantile of each entry within its column, in (0, 1]."""
    F = np.atleast_2d(np.asarray(F, float))
    n = len(F)
    Q = np.empty_like(F)
    for j in range(F.shape[1]):
        order = np.argsort(F[:, j], kind="stable")
        vals = F[order, j]
        ranks = np.empty(n, float)
        ends = np.flatnonzero(np.r_[vals[1:] != vals[:-1], True])
        start = 0
        for end in ends:                        # tied values share the upper rank
            ranks[order[start:end + 1]] = end + 1
            start = end + 1
        Q[:, j] = ranks / n
    return Q


def dss(F, k, coords="quantile"):
    """Indices (sorted) of ``k`` points of ``F`` chosen by distance-based subset
    selection. Returns all indices when ``len(F) <= k``."""
    F = np.atleast_2d(np.asarray(F, float))
    if len(F) <= k:
        return np.arange(len(F))
    if coords in ("quantile", "quant"):
        C = quantile_coords(F)
    elif coords in ("normalized", "norm"):
        lo, hi = F.min(axis=0), F.max(axis=0)
        C = (F - lo) / np.maximum(hi - lo, 1e-12)
    else:
        raise ValueError(f"coords must be 'quantile' or 'normalized', not {coords!r}")
    first = int(np.argmin(C.sum(axis=1)))
    chosen = [first]
    d = np.linalg.norm(C - C[first][None, :], axis=1)
    for _ in range(k - 1):
        i = int(np.argmax(d))
        chosen.append(i)
        d = np.minimum(d, np.linalg.norm(C - C[i][None, :], axis=1))
    return np.array(sorted(chosen), dtype=int)
