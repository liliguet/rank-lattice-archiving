# -*- coding: utf-8 -*-
"""Partition-relaxed evolutionary algorithm (PRD).

Two partitions
    The archive and the environmental selection use separate partitions. The
    archive partition is fine, so that its coverage level delta is small, and
    the selection partition is coarse, so that cells hold several candidates
    and compete. With a single fine partition almost every cell holds one
    point and the selection reduces to a global rank-sum ordering.

Mating
    ``guide="none"`` pairs parents at random, which is the setting used in the
    paper. ``"cell"`` pairs members of the same selection cell first, and
    ``"kernel"`` samples partners by the collision kernel of a Mondrian
    partition.

Cost
    Cell lookup is O(M log n) on the rank lattice, the global dominance filter
    of the archive is O(|A| M), and the environmental selection is O(M N^2).
"""
from __future__ import annotations

import numpy as np

from .archive import QuotientArchive, rank_sum_key


# ------------------------------------------------------------------ variation
def sbx_crossover(p1, p2, lo, hi, eta=20.0, rng=None):
    rng = rng or np.random.default_rng()
    u = rng.random(len(p1))
    beta = np.where(u <= 0.5, (2 * u) ** (1 / (eta + 1)),
                    (1 / (2 * (1 - u))) ** (1 / (eta + 1)))
    c1 = 0.5 * ((1 + beta) * p1 + (1 - beta) * p2)
    c2 = 0.5 * ((1 - beta) * p1 + (1 + beta) * p2)
    return np.clip(c1, lo, hi), np.clip(c2, lo, hi)


def poly_mutation(x, lo, hi, eta=20.0, pm=None, rng=None):
    rng = rng or np.random.default_rng()
    pm = pm if pm is not None else 1.0 / len(x)
    y = x.copy()
    mask = rng.random(len(x)) < pm
    if not mask.any():
        return y
    u = rng.random(len(x))
    d = np.where(u < 0.5, (2 * u) ** (1 / (eta + 1)) - 1,
                 1 - (2 * (1 - u)) ** (1 / (eta + 1)))
    y[mask] = np.clip(y[mask] + d[mask] * (hi - lo)[mask], lo[mask], hi[mask])
    return y


def nondominated_mask(F):
    F = np.asarray(F, dtype=float)
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    return ~(le & lt).any(axis=0)


def nondominated_sort(F):
    """Nondomination layer of every row (0 for the first front), vectorized."""
    F = np.asarray(F, dtype=float)
    n = len(F)
    le = np.all(F[:, None, :] <= F[None, :, :], axis=2)
    lt = np.any(F[:, None, :] < F[None, :, :], axis=2)
    dom = le & lt                       # dom[i, j]: i dominates j
    counts = dom.sum(axis=0).astype(int)
    rank = np.full(n, -1, dtype=int)
    cur = np.where(counts == 0)[0]
    layer = 0
    while len(cur):
        rank[cur] = layer
        counts = counts - dom[cur].sum(axis=0)
        counts[cur] = -1
        cur = np.where(counts == 0)[0]
        layer += 1
    rank[rank < 0] = layer
    return rank


# ------------------------------------------------------------------ cell convergence
def cell_convergence(partition, cid):
    """Cell-level convergence proxy on an order-sound partition, the sum of the
    cell index (the partition analogue of GrEA's grid ranking).

    On the rank lattice it depends on ranks only and is therefore compatible
    with Theorem 2. Returns None on partitions without an index order, and the
    caller then truncates at random.
    """
    key = partition.cell_key(cid)
    return None if key is None else int(sum(key))


# ------------------------------------------------------------------ environmental selection
def prd_environmental_selection(F, N, partition, rng=None, cut="random"):
    """Nondominated sorting with one representative per cell and layer.
    Returns (selected indices, number of occupied cells in the first layer).

    When a layer occupies more cells than there is room for, which is the
    usual case with many objectives, the cells are truncated at random
    (``cut="random"``, the setting of the paper) or by cell convergence
    (``cut="conv"``).
    """
    F = np.asarray(F, dtype=float)
    rng = rng or np.random.default_rng()
    ranks = nondominated_sort(F)
    selected, spare_pool = [], []
    n_cells_first = 0
    for layer in range(int(ranks.max()) + 1):
        if len(selected) >= N:
            break
        idxs = np.where(ranks == layer)[0]
        groups: dict = {}
        for i in idxs:
            groups.setdefault(partition.assign(F[i]), []).append(int(i))
        if layer == 0:
            n_cells_first = len(groups)
        reps, spares, rep_cid = [], [], []
        for cid, members in groups.items():
            sub = F[members]
            keyed = sorted(members, key=lambda i: rank_sum_key(F[i], sub))
            reps.append(keyed[0]); rep_cid.append(cid)
            spares.extend(keyed[1:])
        room = N - len(selected)
        if len(reps) <= room:
            rng.shuffle(reps)
            selected.extend(reps)
            spare_pool.extend(spares)
        else:
            conv = ([cell_convergence(partition, c) for c in rep_cid]
                    if cut == "conv" else [None])
            if cut == "conv" and all(c is not None for c in conv):
                order = sorted(range(len(reps)),
                               key=lambda t: (conv[t], rng.random()))
            else:
                order = list(rng.permutation(len(reps)))
            selected.extend([reps[t] for t in order[:room]])
    if len(selected) < N and spare_pool:
        rng.shuffle(spare_pool)
        selected.extend(spare_pool[: N - len(selected)])
    if len(selected) < N:
        chosen = set(selected)
        rest = [i for i in range(len(F)) if i not in chosen]
        rng.shuffle(rest)
        selected.extend(rest[: N - len(selected)])
    return selected[:N], n_cells_first


# ------------------------------------------------------------------ mating
def guided_pairing(F, partition, rng, mode="cell"):
    """Parent pairs. ``mode`` is 'none', 'cell' or 'kernel'."""
    n = len(F)
    if mode == "none" or n < 2:
        order = rng.permutation(n)
        return [(int(order[i]), int(order[i + 1])) for i in range(0, n - 1, 2)]
    if mode == "kernel" and hasattr(partition, "collision_kernel"):
        order = rng.permutation(n)
        pairs = []
        for i in range(0, n - 1, 2):
            a = int(order[i])
            cand = rng.choice(n, size=min(8, n), replace=False)
            w = np.array([partition.collision_kernel(F[a], F[int(c)]) + 1e-9
                          for c in cand])
            b = int(cand[rng.choice(len(cand), p=w / w.sum())])
            pairs.append((a, b if b != a else int(order[i + 1])))
        return pairs
    cells: dict = {}
    for i in range(n):
        cells.setdefault(partition.assign(F[i]), []).append(i)
    pairs, used = [], set()
    for cid, members in cells.items():
        m = list(members)
        rng.shuffle(m)
        for k in range(0, len(m) - 1, 2):
            pairs.append((m[k], m[k + 1]))
            used.add(m[k]); used.add(m[k + 1])
    left = [i for i in range(n) if i not in used]
    rng.shuffle(left)
    for k in range(0, len(left) - 1, 2):
        pairs.append((left[k], left[k + 1]))
    return pairs


# ------------------------------------------------------------------ main loop
class PRDEA:
    """Partition-relaxed algorithm.

    partition_factory  factory of the archive partition (fine)
    sel_factory        factory of the selection partition (coarse); None
                       reuses the archive partition
    guide              'none' | 'cell' | 'kernel'
    refit_every        period, in generations, at which the offspring are
                       appended to the reference sets; the archive is never
                       refiltered under the refreshed partition
    archive_mode       'S' | 'tau'
    """

    def __init__(self, problem, partition_factory, sel_factory=None,
                 pop_size=100, refit_every=20, archive_mode="S",
                 guide="cell", cut="random", seed=0, track_history=False, track_proposed: bool = False):
        self.problem = problem
        self.partition_factory = partition_factory
        self.sel_factory = sel_factory
        self.N = int(pop_size)
        self.refit_every = int(refit_every)
        self.track_proposed = track_proposed
        self.archive_mode = archive_mode
        self.guide = guide
        self.cut = cut          # 'random' | 'conv' (truncation by cell-index sum)
        self.seed = int(seed)
        self.track_history = track_history
        self.rng = np.random.default_rng(seed)

    def run(self, n_gen=100, max_fe=None, init_X=None, init_F=None, fe_used=0):
        """Run the algorithm. When ``init_X``/``init_F`` are given the run continues
        from that population, which charges the calibration warm-up to the
        budget, and ``fe_used`` is the number of evaluations already spent."""
        pb = self.problem
        rng = self.rng
        if init_X is not None:
            X = np.asarray(init_X, dtype=float).copy()
            F = (np.asarray(init_F, dtype=float).copy() if init_F is not None
                 else pb.evaluate(X))
            fe = int(fe_used)
        else:
            X = rng.uniform(pb.lo, pb.hi, size=(self.N, pb.n_var))
            F = pb.evaluate(X)
            fe = self.N
        part = self.partition_factory().fit(F)
        sel_part = self.sel_factory().fit(F) if self.sel_factory else part
        archive = QuotientArchive(part, mode=self.archive_mode,
                                  track_proposed=getattr(self, "track_proposed", False))
        archive.bulk_init(F, data_list=list(X), ident_list=[(0, k) for k in range(len(F))])
        history = []
        for gen in range(n_gen):
            if max_fe is not None and fe >= max_fe:
                break
            if hasattr(pb, "tick"):
                pb.tick(gen, n_gen)
            pairs = guided_pairing(F, sel_part, rng, mode=self.guide)
            children = []
            for a, b in pairs:
                c1, c2 = sbx_crossover(X[a], X[b], pb.lo, pb.hi, rng=rng)
                children.append(poly_mutation(c1, pb.lo, pb.hi, rng=rng))
                children.append(poly_mutation(c2, pb.lo, pb.hi, rng=rng))
            CX = np.array(children[: self.N])
            CF = pb.evaluate(CX)
            fe += len(CX)
            # Offspring are submitted in the logical order (generation, index in
            # the batch), independent of the order in which evaluations finish.
            # The sticky rule (U3) depends on this order, so the archive is
            # reproducible because the logical stream is fixed by the seed. The
            # identifier makes the duplicate rule (U0) independent of it.
            for k, (x, f) in enumerate(zip(CX, CF)):
                archive.submit(f, data=x, ident=(gen + 1, k))
            AX = np.vstack([X, CX])
            AF = np.vstack([F, CF])
            sel, nb = prd_environmental_selection(AF, self.N, sel_part,
                                                  rng=rng, cut=self.cut)
            X, F = AX[sel], AF[sel]
            if self.refit_every and (gen + 1) % self.refit_every == 0:
                seen = set()
                for p in (part, sel_part):
                    if id(p) in seen:
                        continue
                    seen.add(id(p))
                    try:
                        p.refresh(CF)
                    except NotImplementedError:
                        pass
            if self.track_history:
                history.append((gen + 1, fe, len(archive.reps), nb))
        return {"X": X, "F": F, "archive": archive, "history": history,
                "fe": fe, "partition": part, "sel_partition": sel_part}


# ------------------------------------------------------------------ problems
class DTLZ2:
    """DTLZ2 for quick tests. The experiments use pymoo's DTLZ and WFG and the MaF problems of pdom.problems."""

    def __init__(self, M=3, k=10):
        self.M = int(M)
        self.n_var = self.M - 1 + int(k)
        self.lo = np.zeros(self.n_var)
        self.hi = np.ones(self.n_var)

    def evaluate(self, X):
        X = np.atleast_2d(np.asarray(X, dtype=float))
        M = self.M
        g = np.sum((X[:, M - 1:] - 0.5) ** 2, axis=1)
        F = np.ones((X.shape[0], M))
        for m in range(M):
            f = 1.0 + g
            for j in range(M - 1 - m):
                f *= np.cos(0.5 * np.pi * X[:, j])
            if m > 0:
                f *= np.sin(0.5 * np.pi * X[:, M - 1 - m])
            F[:, m] = f
        return F


class ScaledProblem:
    """Static scaling, objective j multiplied by scales[j]."""

    def __init__(self, base, scales=None):
        self.base = base
        self.n_var, self.lo, self.hi, self.M = base.n_var, base.lo, base.hi, base.M
        self.scales = np.asarray(scales, float) if scales is not None else None

    def evaluate(self, X):
        F = self.base.evaluate(X)
        return F * self.scales if self.scales is not None else F

    def true_objectives(self, X):
        return self.base.evaluate(X)


class DriftScaledProblem:
    """Scale drift during the run, scale_j(t) = 10^(j (0.5 + t/T)) for j = 0, ..., M-1."""

    def __init__(self, base):
        self.base = base
        self.n_var, self.lo, self.hi, self.M = base.n_var, base.lo, base.hi, base.M
        self._phase = 0.5

    def tick(self, gen, n_gen):
        self._phase = 0.5 + gen / max(n_gen, 1)

    def current_scales(self):
        return np.array([10.0 ** (j * self._phase) for j in range(self.M)])

    def evaluate(self, X):
        return self.base.evaluate(X) * self.current_scales()

    def true_objectives(self, X):
        return self.base.evaluate(X)


class OutlierProblem:
    """Outlier contamination.

    A small region of the decision space has objective values inflated by
    several orders of magnitude. These solutions are dominated by the front
    but enter the population, and they move every estimate of the nadir point
    and of the objective ranges. The rank lattice counts an outlier as one
    rank. The front is unchanged, so IGD+ is computed on the reference front
    of the base problem.
    """

    def __init__(self, base, region=0.05, blowup=1e3, asymmetric=False,
                 seed=0):
        """With ``asymmetric=False`` every objective of an outlier is multiplied by
        the same factor, which leaves the angles after normalization unchanged.
        With ``asymmetric=True`` the region is split into M segments along
        x[0] and segment j inflates objective j only.
        """
        self.base = base
        self.n_var, self.lo, self.hi, self.M = base.n_var, base.lo, base.hi, base.M
        self.region = float(region)
        self.blowup = float(blowup)
        self.asymmetric = bool(asymmetric)
        self.seed = int(seed)

    def evaluate(self, X):
        X = np.atleast_2d(np.asarray(X, dtype=float))
        F = self.base.evaluate(X)
        span = np.maximum(self.hi[0] - self.lo[0], 1e-12)
        u = (X[:, 0] - self.lo[0]) / span
        mask = u < self.region
        if not mask.any():
            return F
        F = F.copy()
        if not self.asymmetric:
            F[mask] *= self.blowup
            return F
        # the region is split into M segments along x[0]; segment j inflates objective j
        seg = np.minimum((u[mask] / self.region * self.M).astype(int), self.M - 1)
        idx = np.where(mask)[0]
        for j in range(self.M):
            sel = idx[seg == j]
            if len(sel):
                F[sel, j] *= self.blowup
        return F

    def true_objectives(self, X):
        return self.evaluate(X)


class DriftOutlierProblem:
    """Scale drift combined with outlier contamination."""

    def __init__(self, base, region=0.05, blowup=1e3):
        self.base = base
        self.n_var, self.lo, self.hi, self.M = base.n_var, base.lo, base.hi, base.M
        self._out = OutlierProblem(base, region, blowup)
        self._phase = 0.5

    def tick(self, gen, n_gen):
        self._phase = 0.5 + gen / max(n_gen, 1)

    def current_scales(self):
        return np.array([10.0 ** (j * self._phase) for j in range(self.M)])

    def evaluate(self, X):
        return self._out.evaluate(X) * self.current_scales()

    def true_objectives(self, X):
        return self._out.evaluate(X)


class NonlinearProblem:
    """Static monotone distortion, log1p on objectives with even index and the cube on objectives with odd index (0-based)."""

    def __init__(self, base):
        self.base = base
        self.n_var, self.lo, self.hi, self.M = base.n_var, base.lo, base.hi, base.M

    def evaluate(self, X):
        F = self.base.evaluate(X)
        G = F.copy()
        for j in range(self.M):
            G[:, j] = np.power(F[:, j], 3.0) if j % 2 else np.log1p(F[:, j])
        return G

    def true_objectives(self, X):
        return self.base.evaluate(X)
