# -*- coding: utf-8 -*-
"""Conservative quotient update (Definition 3 and Algorithm 1 of the paper).

Design decisions
  * Mode S (the sticky rule U3) is safe on every partition. Mode tau is
    accepted only on order-sound partitions (Theorem 1); reproducing the
    counterexample of the Supplementary Material on another partition requires
    ``allow_unsafe_tau=True``.
  * The tie-break key is stored with the representative and never recomputed
    for the incumbent at submission time.
  * Cell-order pruning (Lemma 1) is available only on order-sound partitions
    and is on by default there. It preserves single-delta coverage but not
    strict elitism (Theorem 1(c)); pass ``cell_order_prune=False`` to keep
    strict elitism.
  * After a refresh of the reference set the archive is not refiltered under
    the new partition, and the class offers no method to do so. Members keep
    the cell in which they entered.
"""
from __future__ import annotations

import numpy as np


def dominates(a: np.ndarray, b: np.ndarray) -> bool:
    return bool(np.all(a <= b) and np.any(a < b))


def weakly_dominates(a: np.ndarray, b: np.ndarray) -> bool:
    return bool(np.all(a <= b))


def rank_sum_key(y: np.ndarray, cell_members: np.ndarray):
    """Rank-sum tie-break key of Lemma 2, computed at batch initialization only and stored with the representative."""
    r = np.array([int(np.count_nonzero(cell_members[:, j] < y[j]))
                  for j in range(len(y))], dtype=np.int64)
    return (int(r.sum()), tuple(int(x) for x in r))


class QuotientArchive:
    def __init__(self, partition, mode: str = "S",
                 cell_order_prune: bool | None = None,
                 allow_unsafe_tau: bool = False,
                 track_proposed: bool = False):
        assert mode in ("S", "tau")
        if mode == "tau" and not partition.orderable and not allow_unsafe_tau:
            raise ValueError(
                "Mode tau is safe only on order-sound partitions (Theorem 1). Use Mode S, "
                "or pass allow_unsafe_tau=True to reproduce the counterexample.")
        self.partition = partition
        self.mode = mode
        self.prune = (partition.orderable if cell_order_prune is None
                      else bool(cell_order_prune and partition.orderable))
        self.reps: dict = {}        # cid -> objective vector
        self.rep_data: dict = {}    # cid -> payload (decision vector etc.)
        self.rep_tau: dict = {}     # cid -> stored tie-break key
        self.rep_ident: dict = {}   # cid -> identifier (rule U0, independent of arrival order)
        self._mat = None            # cached matrix of members (vectorized dominance tests)
        self._mat_cids = None
        self.track_proposed = track_proposed
        self.proposed = []
        self.n_submit = 0
        self.stats = {"reject_dom": 0, "reject_sticky": 0, "reject_tau": 0,
                      "accept_empty": 0, "accept_dom": 0, "accept_tau": 0,
                      "prune_cell": 0}

    # ------------------------------------------------------------------ internals
    def _cache(self):
        if self._mat is None:
            self._mat_cids = list(self.reps.keys())
            self._mat = (np.array([self.reps[c] for c in self._mat_cids])
                         if self.reps else np.empty((0, 1)))
        return self._mat

    def _drop(self, cid):
        self.reps.pop(cid, None)
        self.rep_data.pop(cid, None)
        self.rep_tau.pop(cid, None)
        self.rep_ident.pop(cid, None)
        self._mat = None

    def _remove_dominated_by(self, z):
        mat = self._cache()
        if len(mat) == 0:
            return
        dom = np.all(z <= mat, axis=1) & np.any(z < mat, axis=1)
        for cid in [self._mat_cids[i] for i in np.where(dom)[0]]:
            self._drop(cid)

    def _cell_order_prune(self, z_cid):
        """Delete members whose cell index is strictly preceded by that of ``z_cid`` (Lemma 1), on order-sound partitions only."""
        zk = self.partition.cell_key(z_cid)
        drop = []
        for cid in self.reps:
            if cid == z_cid:
                continue
            ck = self.partition.cell_key(cid)
            if all(a <= b for a, b in zip(zk, ck)) and zk != ck:
                drop.append(cid)
        for cid in drop:
            self._drop(cid)
            self.stats["prune_cell"] += 1

    # ------------------------------------------------------------------ update
    def submit(self, z: np.ndarray, data=None, tau_key=None, ident=None) -> str:
        """Submit one proposal (rules U0 to U4 of Definition 3).

        Rule U0 resolves a duplicate objective vector by the order of the
        identifiers, not by arrival order, so that the archive does not depend
        on the order in which parallel evaluations finish. Identifiers must be
        mutually comparable (integers or tuples). Without ``ident`` a duplicate
        is rejected and counted in ``stats["dup_no_ident"]``.
        """
        z = np.asarray(z, dtype=float)
        self.n_submit += 1
        if self.track_proposed:
            self.proposed.append(z.copy())
        cid = self.partition.assign(z)

        mat0 = self._cache()                              # U0 duplicate objective vector
        if len(mat0):
            same = np.where(np.all(mat0 == z, axis=1))[0]
            if len(same):
                k = self._mat_cids[int(same[0])]
                if ident is None:
                    self.stats["dup_no_ident"] = self.stats.get("dup_no_ident", 0) + 1
                    return "reject_dup"
                cur = self.rep_ident.get(k)
                if cur is not None and cur <= ident:
                    return "reject_dup"
                self.reps[k] = z.copy()
                self.rep_data[k] = data
                self.rep_tau[k] = tau_key
                self.rep_ident[k] = ident
                self._mat = None
                self.stats["accept_dup"] = self.stats.get("accept_dup", 0) + 1
                return "accept_dup"

        mat = self._cache()                               # U1 weakly dominated: reject
        if len(mat) and np.all(mat <= z, axis=1).any():
            self.stats["reject_dom"] += 1
            return "reject_dom"

        incumbent = self.reps.get(cid)
        if incumbent is None:                             # U4 empty cell: admit
            self._remove_dominated_by(z)
            self.reps[cid] = z.copy()
            self.rep_data[cid] = data
            self.rep_tau[cid] = tau_key
            self.rep_ident[cid] = ident
            self._mat = None
            if self.prune:
                self._cell_order_prune(cid)
            self.stats["accept_empty"] += 1
            return "accept_empty"

        if dominates(z, incumbent):                       # U2 dominates incumbent: replace
            self.reps[cid] = z.copy()
            self.rep_data[cid] = data
            self.rep_tau[cid] = tau_key
            self.rep_ident[cid] = ident
            self._mat = None
            self._remove_dominated_by(z)
            if self.prune:
                self._cell_order_prune(cid)
            self.stats["accept_dom"] += 1
            return "accept_dom"

        if self.mode == "S":                              # U3 incomparable: keep incumbent
            self.stats["reject_sticky"] += 1
            return "reject_sticky"

        stored = self.rep_tau.get(cid)                    # Mode tau: swap on a better key
        if tau_key is not None and stored is not None and tau_key < stored:
            self.reps[cid] = z.copy()
            self.rep_data[cid] = data
            self.rep_tau[cid] = tau_key
            self.rep_ident[cid] = ident
            self._mat = None
            self.stats["accept_tau"] += 1
            return "accept_tau"
        self.stats["reject_tau"] += 1
        return "reject_tau"

    # ------------------------------------------------------------------ batch
    def bulk_init(self, Y: np.ndarray, data_list=None, ident_list=None):
        """Batch initialization (end of Definition 3). Each cell keeps one member
        of its nondominated subset by the rank-sum tie-break, followed by one
        global nondominance filter. The keys are computed here once and stored."""
        Y = np.asarray(Y, dtype=float)
        groups: dict = {}
        for i, y in enumerate(Y):
            groups.setdefault(self.partition.assign(y), []).append(i)
        for cid, idxs in groups.items():
            members = Y[idxs]
            nd = [i for i in idxs
                  if not any(dominates(Y[j], Y[i]) for j in idxs if j != i)]
            keyed = sorted(nd, key=lambda i: rank_sum_key(Y[i], members))
            pick = keyed[0]
            self.reps[cid] = Y[pick].copy()
            self.rep_data[cid] = None if data_list is None else data_list[pick]
            self.rep_tau[cid] = rank_sum_key(Y[pick], members)
            self.rep_ident[cid] = None if ident_list is None else ident_list[pick]
        self._mat = None
        for cid in [c for c, a in self.reps.items()
                    if any(dominates(b, a) for b in self.reps.values())]:
            self._drop(cid)
        return self

    # ------------------------------------------------------------------ audit
    def members(self) -> np.ndarray:
        return np.array(list(self.reps.values())) if self.reps else np.empty((0, 0))

    def coverage_violations(self, metric: str = "auto") -> int:
        """Number of proposals without a delta-witness (Theorem 1(b)). Requires
        ``track_proposed=True``. ``metric="rank"`` audits in the rank metric
        (rank lattice), ``"linf"`` in L_inf (affine grid) and ``"auto"`` chooses
        by partition; a partition without a diameter bound is audited for an
        f-witness (strict elitism, Theorem 1(a))."""
        assert self.track_proposed, "requires track_proposed=True"
        A = self.members()
        if len(A) == 0:
            return len(self.proposed)
        delta = self.partition.diameter_bound()
        viol = 0
        for z in self.proposed:
            if delta is None:
                ok = any(weakly_dominates(a, z) for a in A)
            elif metric in ("rank", "auto") and getattr(self.partition, "Fhat", None):
                Fz = self.partition.Fhat(z)
                ok = any(np.all(self.partition.Fhat(a) <= Fz + delta + 1e-9) for a in A)
            else:
                ok = any(np.all(a <= z + delta + 1e-9) for a in A)
            viol += 0 if ok else 1
        return viol
