# -*- coding: utf-8 -*-
"""Quality indicators and statistical tests.

  * IGD+ and HV are computed in the true objective space. In the experiments
    with rescaled objectives the solutions are re-evaluated on the base
    problem first, so that the indicator is not affected by the rescaling.
  * The identity audit compares the sets of retained stream positions, which
    is an exact criterion.
  * Pairwise comparisons use the Wilcoxon signed-rank test with the Holm
    correction and the Vargha-Delaney A12 effect size, and comparisons of
    several algorithms use the Friedman test with the Nemenyi critical
    difference.
"""
from __future__ import annotations

import numpy as np

try:
    from scipy.stats import wilcoxon as _wilcoxon
except ImportError:  # degrade gracefully without scipy
    _wilcoxon = None


# ------------------------------------------------------------------ indicators
def igd_plus(A: np.ndarray, ref_front: np.ndarray) -> float:
    A = np.atleast_2d(A)
    d = np.empty(len(ref_front))
    for i, r in enumerate(ref_front):
        diff = np.maximum(A - r, 0.0)
        d[i] = np.sqrt((diff ** 2).sum(axis=1)).min()
    return float(d.mean())


def igd_plus_normalized(A: np.ndarray, ref_front: np.ndarray) -> float:
    """IGD+ after normalizing every objective by the range of the reference front.

    Unnormalized IGD+ is dominated by the objectives with the largest range
    (on WFG, f_j ranges over [0, 2j], so objective 10 weighs ten times as much
    as objective 1).
    """
    lo, hi = ref_front.min(axis=0), ref_front.max(axis=0)
    rng = np.maximum(hi - lo, 1e-12)
    return igd_plus((np.atleast_2d(A) - lo) / rng, (ref_front - lo) / rng)


def hv_monte_carlo(A: np.ndarray, ref_point: np.ndarray,
                   n_samples: int = 200_000, seed: int = 0) -> float:
    """Monte Carlo estimate of the hypervolume (use an exact method for small M)."""
    A = np.atleast_2d(A)
    rng = np.random.default_rng(seed)
    lo = A.min(axis=0)
    S = rng.uniform(lo, ref_point, size=(n_samples, len(ref_point)))
    dominated = np.zeros(n_samples, dtype=bool)
    for a in A:
        dominated |= np.all(S >= a, axis=1)
    box = np.prod(ref_point - lo)
    return float(dominated.mean() * box)


def dtlz2_ref_front(M: int, n: int = 2000, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    V = np.abs(rng.normal(size=(n, M)))
    return V / np.linalg.norm(V, axis=1, keepdims=True)


# ------------------------------------------------------------------ identity audit
def transform_battery(M: int, seed: int = 0):
    """Battery of componentwise strictly increasing maps, {name: list of per-objective functions}."""
    rng = np.random.default_rng(seed)
    slope = rng.uniform(0.5, 5.0, size=M)
    shift = rng.uniform(-10.0, 10.0, size=M)
    return {
        "log":  [lambda v, j=j: np.log(v + 1.0) for j in range(M)],
        "pow3": [lambda v, j=j: np.power(v, 3.0) for j in range(M)],
        "aff":  [lambda v, j=j: v * slope[j] + shift[j] for j in range(M)],
        "mix":  [(lambda v, j=j: np.log(v + 1.0)) if j % 2 == 0
                 else (lambda v, j=j: np.power(v, 3.0)) for j in range(M)],
    }


def archive_row_ids(F_pool: np.ndarray, A: np.ndarray) -> frozenset:
    rows = set()
    for a in A:
        hit = np.where(np.all(np.isclose(F_pool, a, rtol=1e-9, atol=1e-12), axis=1))[0]
        if len(hit):
            rows.add(int(hit[0]))
    return frozenset(rows)


# ------------------------------------------------------------------ statistics
def vargha_delaney_a12(x, y) -> float:
    x, y = np.asarray(x, float), np.asarray(y, float)
    gt = sum((xi > y).sum() for xi in x)
    eq = sum((xi == y).sum() for xi in x)
    return float((gt + 0.5 * eq) / (len(x) * len(y)))


def paired_wilcoxon(x, y):
    if _wilcoxon is None:
        d = np.asarray(x) - np.asarray(y)
        k = min((d > 0).sum(), (d < 0).sum())
        return {"stat": float(k), "p": float("nan"), "note": "scipy missing, sign-test statistic only"}
    stat, p = _wilcoxon(x, y, zero_method="wilcox", alternative="two-sided")
    return {"stat": float(stat), "p": float(p)}


def holm_correction(pvals):
    order = np.argsort(pvals)
    m = len(pvals)
    adj = np.empty(m)
    running = 0.0
    for rank, i in enumerate(order):
        running = max(running, (m - rank) * pvals[i])
        adj[i] = min(running, 1.0)
    return adj.tolist()


# ------------------------------------------------------------------ several algorithms
def friedman_test(score_matrix):
    """Friedman test. ``score_matrix`` is [n_problems, n_algorithms], smaller is
    better. Returns (statistic, p value, average ranks); without scipy the
    statistic and p value are NaN."""
    S = np.asarray(score_matrix, dtype=float)
    n, k = S.shape
    ranks = np.apply_along_axis(lambda r: _avg_rank(r), 1, S)
    avg = ranks.mean(axis=0)
    try:
        from scipy.stats import friedmanchisquare
        stat, p = friedmanchisquare(*[S[:, j] for j in range(k)])
        return float(stat), float(p), avg
    except Exception:
        return float("nan"), float("nan"), avg


def _avg_rank(row):
    order = np.argsort(row, kind="stable")
    r = np.empty(len(row))
    i = 0
    while i < len(row):
        j = i
        while j + 1 < len(row) and row[order[j + 1]] == row[order[i]]:
            j += 1
        r[order[i:j + 1]] = (i + j) / 2 + 1
        i = j + 1
    return r


def nemenyi_cd(k, n, alpha=0.05):
    """Nemenyi critical difference, with q_alpha from Demšar (2006) for k up to 20."""
    q = {2:1.960,3:2.343,4:2.569,5:2.728,6:2.850,7:2.949,8:3.031,9:3.102,10:3.164,
         11:3.219,12:3.268,13:3.313,14:3.354,15:3.391,16:3.426,17:3.458,18:3.489,
         19:3.517,20:3.544}[min(max(k,2),20)]
    return q * np.sqrt(k * (k + 1) / (6.0 * n))
