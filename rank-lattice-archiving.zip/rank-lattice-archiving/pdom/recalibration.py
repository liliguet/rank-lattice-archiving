# -*- coding: utf-8 -*-
"""Arithmetic check for a recalibration evaluated in floating point.

The invariance of the rank lattice holds for every componentwise strictly
increasing map. A map evaluated in binary64 can fail to be strictly increasing
on the values that actually occur: a compressive map such as ``log`` or
``log1p`` can send two distinct values to the same number, and so can the
rounding of a reciprocal when the two values are one unit in the last place
apart. The recalibrated stream then has a tie that the original stream does
not have, and the archives computed from the two streams can differ.

``order_violations`` counts, per objective, the pairs of adjacent distinct
values whose images are not strictly increasing. A count of zero on every
objective certifies that the map is strictly increasing on the recorded values,
so that the rank lattice returns the same members for both streams.

``order_preserving`` repairs a recorded recalibration. Wherever the image of a
larger value does not exceed the image of the next smaller one, it is moved to
the next representable number above it. The result is strictly increasing on
the recorded values and induces the same order as the pair (g(v), v) compared
lexicographically, which is the order-preserving secondary key of the paper.
"""
from __future__ import annotations

import numpy as np


def _columns(F, G):
    F = np.atleast_2d(np.asarray(F, float))
    G = np.atleast_2d(np.asarray(G, float))
    if F.shape != G.shape:
        raise ValueError(f"shapes differ: {F.shape} and {G.shape}")
    return F, G


def order_violations(F, G):
    """Per objective, the number of adjacent pairs of distinct values of ``F``
    whose images in ``G`` (same rows) are not strictly increasing."""
    F, G = _columns(F, G)
    out = np.zeros(F.shape[1], dtype=int)
    for j in range(F.shape[1]):
        vals, first = np.unique(F[:, j], return_index=True)
        img = G[first, j]
        if not np.all(G[:, j] == img[np.searchsorted(vals, F[:, j])]):
            raise ValueError(f"objective {j}: equal values in F map to different values in G")
        out[j] = int(np.count_nonzero(np.diff(img) <= 0))
    return out


def order_preserving(F, G):
    """Return a copy of ``G`` that is strictly increasing in ``F`` on every
    objective, obtained by moving coalesced images up by one representable
    number at a time. Rows of ``G`` that are already strictly ordered are left
    unchanged."""
    F, G = _columns(F, G)
    H = G.copy()
    for j in range(F.shape[1]):
        vals, first = np.unique(F[:, j], return_index=True)
        img = G[first, j].copy()
        for k in range(1, len(img)):
            if img[k] <= img[k - 1]:
                img[k] = np.nextafter(img[k - 1], np.inf)
        H[:, j] = img[np.searchsorted(vals, F[:, j])]
    return H
