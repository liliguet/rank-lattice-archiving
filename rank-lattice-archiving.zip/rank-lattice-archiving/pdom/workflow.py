# -*- coding: utf-8 -*-
"""High-level entry points.

``run_prd``        runs the partition-relaxed algorithm in the configuration used
                   in the paper, with the rank-lattice archive and nearest-anchor
                   selection (the "rank-archive configuration").
``run_baseline``   runs one of the ten baselines of the paper.
``RankLatticeCollector`` attaches a rank-lattice archive to any pymoo algorithm
                   as a passive collector, which is the use recommended in the paper.
"""
from __future__ import annotations

import os
from math import comb

import numpy as np

from .algorithm import PRDEA, sbx_crossover, poly_mutation, nondominated_sort
from .archive import QuotientArchive
from .calibrate import load_or_calibrate, make_factory
from .partitions import RankGridPartition

# Population sizes used in the paper (two-layer reference sets).
POP_SIZE = {3: 92, 5: 212, 8: 156, 10: 276, 15: 136}


def pop_size_for(M):
    return POP_SIZE.get(M, 200)


def das_dennis_layers(M, N):
    """Das-Dennis reference directions with about N points (two layers for large M)."""
    from pymoo.util.ref_dirs import get_reference_directions
    best, best_gap = 1, float("inf")
    for H in range(1, 40):
        n = comb(H + M - 1, M - 1)
        if n > 4 * N:
            break
        if abs(n - N) < best_gap:
            best, best_gap = H, abs(n - N)
    W = get_reference_directions("das-dennis", M, n_partitions=best)
    if len(W) < 0.6 * N and M > 5:
        inner = get_reference_directions("das-dennis", M, n_partitions=max(best - 1, 1))
        W = np.vstack([W, inner * 0.5 + 0.5 / M])
    return W


def as_pymoo_problem(prob):
    """Wrap a problem of this package as a pymoo Problem."""
    if hasattr(prob, "_p"):                      # already backed by pymoo
        return prob._p
    from pymoo.core.problem import Problem

    class _Shim(Problem):
        def __init__(self):
            super().__init__(n_var=prob.n_var, n_obj=prob.M, xl=prob.lo, xu=prob.hi)

        def _evaluate(self, X, out, *a, **kw):
            out["F"] = prob.evaluate(X)

    return _Shim()


def calibration_pool(prob, N, seed, warmup_gen=30):
    """Warm-up used to calibrate the partitions, charged to the budget.

    The first ``warmup_gen`` generations of the algorithm itself are run from a
    random population, and the pool used for calibration is the union of the
    initial and the warmed-up objective vectors. Returns
    ``(pool, X_warm, F_warm, evaluations_used)``.
    """
    rng = np.random.default_rng(seed)
    X = rng.uniform(prob.lo, prob.hi, size=(N, prob.n_var))
    F = prob.evaluate(X)
    fe, init = N, F.copy()
    for _ in range(warmup_gen):
        idx = rng.permutation(N)
        kids = []
        for i in range(0, N - 1, 2):
            c1, c2 = sbx_crossover(X[idx[i]], X[idx[i + 1]], prob.lo, prob.hi, rng=rng)
            kids.append(poly_mutation(c1, prob.lo, prob.hi, rng=rng))
            kids.append(poly_mutation(c2, prob.lo, prob.hi, rng=rng))
        CX = np.array(kids[:N])
        CF = prob.evaluate(CX)
        fe += len(CX)
        AX, AF = np.vstack([X, CX]), np.vstack([F, CF])
        order = np.argsort(nondominated_sort(AF), kind="stable")[:N]
        X, F = AX[order], AF[order]
    return np.vstack([init, F]), X, F, fe


def run_prd(prob, seed=0, max_fe=100_000, archive="rank_grid", selection="anchor",
            pop_size=None, calib_dir=None):
    """Run the partition-relaxed algorithm.

    ``archive`` and ``selection`` name the partition backends of the two stages.
    The paper's rank-archive configuration is ``archive="rank_grid",
    selection="anchor"``, and ordinal PRD is ``selection="rank_grid"``. Both
    partitions are calibrated on the warm-up pool, the archive to N/2 occupied
    cells and the selection partition to N. Returns the dictionary of
    ``PRDEA.run``, whose ``"archive"`` entry is the final archive.

    By default the calibration is recomputed for every run. A directory given
    as ``calib_dir`` caches it per problem name, number of objectives and seed.
    """
    N = pop_size or pop_size_for(prob.M)
    pool, Xw, Fw, fe = calibration_pool(prob, N, seed)
    tag = f"{getattr(prob, 'name', type(prob).__name__)}_s{seed}"
    if calib_dir is not None:
        os.makedirs(calib_dir, exist_ok=True)
    cfg_a = load_or_calibrate(calib_dir, prob.M, pool, N // 2, seed=seed, tag=f"{tag}_{archive}",
                              backends=[archive])
    cfg_s = load_or_calibrate(calib_dir, prob.M, pool, N, seed=seed, tag=f"{tag}_{selection}",
                              backends=[selection])
    alg = PRDEA(prob, make_factory(archive, cfg_a, seed),
                sel_factory=make_factory(selection, cfg_s, seed),
                pop_size=N, guide="none", seed=seed)
    return alg.run(n_gen=max_fe // N, max_fe=max_fe, init_X=Xw, init_F=Fw, fe_used=fe)


def make_baseline(name, M, N, seed=0):
    """Return a pymoo algorithm object for one of the baselines of the paper,
    with the settings used in the experiments."""
    rd = das_dennis_layers(M, N)
    if name == "sdr":
        from .baseline_sdr import make_sdr
        return make_sdr(pop_size=N)
    if name == "maoea_hap":
        from .baseline_maoea_hap import make_maoea_hap
        return make_maoea_hap(pop_size=N, ref_dirs=rd, seed=seed)
    if name == "leo":
        from .baseline_leo import make_leo
        return make_leo(ref_dirs=rd, pop_size=len(rd), seed=seed)
    if name == "nsga3":
        from pymoo.algorithms.moo.nsga3 import NSGA3
        return NSGA3(pop_size=len(rd), ref_dirs=rd)
    if name == "rvea":
        from pymoo.algorithms.moo.rvea import RVEA
        return RVEA(ref_dirs=rd)
    if name == "moead":
        from pymoo.algorithms.moo.moead import MOEAD
        return MOEAD(ref_dirs=rd, n_neighbors=15, prob_neighbor_mating=0.9)
    if name == "ctaea":
        from pymoo.algorithms.moo.ctaea import CTAEA
        return CTAEA(ref_dirs=rd)
    if name == "agemoea2":
        from pymoo.algorithms.moo.age2 import AGEMOEA2
        return AGEMOEA2(pop_size=N)
    raise ValueError(f"{name} is not a pymoo baseline; GrEA and theta-DEA use run_baseline")


def run_baseline(name, prob, seed=0, max_fe=100_000, pop_size=None):
    """Run a baseline and return its final population's objective vectors."""
    N = pop_size or pop_size_for(prob.M)
    if name == "grea":
        from .baseline_grea import run_grea
        return np.atleast_2d(run_grea(prob, N, max_fe, seed))
    if name == "theta_dea":
        from .baseline_theta_dea import run_theta_dea
        return np.atleast_2d(run_theta_dea(prob, N, max_fe, seed,
                                           ref_dirs=das_dennis_layers(prob.M, N)))
    from pymoo.optimize import minimize
    res = minimize(as_pymoo_problem(prob), make_baseline(name, prob.M, N, seed),
                   ("n_evals", max_fe), seed=seed, verbose=False)
    return np.atleast_2d(res.pop.get("F"))


class RankLatticeCollector:
    """Attach a rank-lattice archive to a pymoo algorithm as a passive collector.

    Use an instance as the ``callback`` of ``pymoo.optimize.minimize``. The
    archive receives the host's population after every generation and never
    feeds back into the search. The first population fits the reference set and
    initializes the archive, and every ``refresh_every`` generations the current
    population is appended to the reference set (0 keeps it fixed). Members keep
    the cell in which they entered.

    Each vector is submitted with its position in the stream of populations as
    identifier, so that duplicate objective vectors are resolved by rule (U0)
    of Definition 3 rather than by arrival order.

    The default configuration of the paper is ``b=3`` with cell-order pruning.
    Every point the host ever reported then keeps a witness within one cell of
    the rank lattice (single-delta coverage). With ``prune=False`` the archive
    also keeps strict elitism, every reported point being weakly dominated by a
    member, at the price of a larger archive.

    >>> col = RankLatticeCollector(b=3)
    >>> minimize(problem, algorithm, ("n_evals", 10000), callback=col)
    >>> col.members()          # objective vectors retained by the archive
    >>> F, X = col.reduce(100) # display set of 100 points, quantile DSS
    """

    def __new__(cls, *args, **kwargs):
        from pymoo.core.callback import Callback

        class _Collector(Callback):
            def __init__(self, b=3, refresh_every=20, mode="S", prune=True):
                super().__init__()
                self.b, self.refresh_every, self.mode = b, refresh_every, mode
                self.prune = bool(prune)
                self.archive, self.gen, self.n_seen = None, 0, 0

            def notify(self, algorithm):
                pop = algorithm.pop
                if pop is None:
                    return
                F, X = np.asarray(pop.get("F"), float), pop.get("X")
                ids = list(range(self.n_seen, self.n_seen + len(F)))
                self.n_seen += len(F)
                if self.archive is None:
                    part = RankGridPartition(b=self.b).fit(F)
                    self.archive = QuotientArchive(part, mode=self.mode,
                                                   cell_order_prune=self.prune)
                    self.archive.bulk_init(F, data_list=list(X), ident_list=ids)
                    return
                for f, x, i in zip(F, X, ids):
                    self.archive.submit(f, data=x, ident=i)
                self.gen += 1
                if self.refresh_every and self.gen % self.refresh_every == 0:
                    self.archive.partition.refresh(F)

            def _cids(self):
                return list(self.archive.reps) if self.archive is not None else []

            def members(self):
                """Objective vectors of the members, in archive order."""
                c = self._cids()
                return (np.array([self.archive.reps[k] for k in c], float) if c
                        else np.empty((0, 0)))

            def decision_vectors(self):
                """Decision vectors of the members, in the order of ``members``."""
                return [self.archive.rep_data[k] for k in self._cids()]

            def idents(self):
                """Stream positions of the members, in the order of ``members``."""
                return np.array([self.archive.rep_ident[k] for k in self._cids()], dtype=int)

            def reduce(self, k, coords="quantile"):
                """Display set of at most ``k`` members chosen by distance-based
                subset selection. Returns (objective vectors, decision vectors).
                With ``coords="quantile"`` the display set is exactly invariant
                along with the archive."""
                from .display import dss
                A = self.members()
                if len(A) == 0:
                    return A, []
                sel = dss(A, k, coords)
                X = self.decision_vectors()
                return A[sel], [X[i] for i in sel]

        return _Collector(*args, **kwargs)
