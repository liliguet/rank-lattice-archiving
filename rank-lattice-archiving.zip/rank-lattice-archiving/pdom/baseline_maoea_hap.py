"""
MaOEA-HAP baseline for pymoo (ported from the authors' PlatEMO source).

    X. Yue, W. Wen, Y. Jiang, Y. Tian, and H. Peng, "A hyper-curvature balanced
    indicator and adaptive phase exploration co-driven evolutionary algorithm for
    many-objective optimization," Swarm and Evolutionary Computation, 2026.

Reference MATLAB (supplied by the authors, PlatEMO format): MaOEAHAP.m,
UpdateCA.m, UpdateDA.m, MatingSelection.m, CrowdDistance.m, NDQSort.m,
AssociateAngle.m, Shape_Estimate.m, flog.m.

------------------------------------------------------------------------------
Algorithm structure (CA/DA dual archive, Two_Arch2 family)
------------------------------------------------------------------------------
  CA (convergence archive, size N): epsilon-indicator (IBEA-style) fitness
      truncation, exactly as Two_Arch2's CA update.
  DA (diversity archive, size N):   angular-dominance first front, then
      truncation that first picks M extreme solutions (masked ASF), then fills
      by a phase-dependent rule:
        k=0 (exploration): fitness = minAngle*(1+2*FE^2/maxFE^2)
                                     * 1/(DAPT*(2-FE^2/maxFE^2))
        k=1 (exploitation): pure max-min-angle
      where DAPT_i = || f_i - proj_Lp(f_i) ||_{1/M} measures each solution's
      deviation from the estimated Lp front shape (Shape_Estimate picks the
      curvature exponent Lp minimizing the spread of the Lp-composite).
  flog: k flips to 1 once all DAPT < 1 (population has wrapped the front shape).
  Mating: ParentC = (CA binary Pareto tournament, ceil(N/2)) + (DA random,
      ceil(N/2)) -> SBX-only offspring;  ParentM = CA crowding-distance
      tournament (N) -> polynomial-mutation-only offspring.
      => the algorithm evaluates ~2N offspring per generation.
  The reported population is the DA archive (PlatEMO: NotTerminated(DA)).

------------------------------------------------------------------------------
Fidelity notes (each verified against the MATLAB line by line)
------------------------------------------------------------------------------
(1) BUDGET: 2N evaluations per generation. For equal-budget comparison, run this
    algorithm with an n_eval termination (as make_baseline/run_baseline do), NOT
    the n_gen used for one-offspring-batch algorithms.
(2) Angular dominance is implemented inside NDQSort's ENS_SS branch, which the
    MATLAB uses only when (M < 3 or N_unique < 500); for larger merged archives
    it calls T_ENS, which is a *standard* efficient non-dominated sort with NO
    angle term. We replicate this branching exactly: the ENS_SS-with-angle path
    is ported verbatim; the T_ENS path is replaced by pymoo's standard
    non-dominated front, which is provably output-equivalent to T_ENS (T_ENS is
    an acceleration of standard dominance sorting, not a different relation).
(3) UpdateDA extreme-solution selection: the MATLAB computes the argmin over the
    not-yet-chosen SUBSET but then uses that subset-relative index as a GLOBAL
    index (`Choose(Extreme(i)) = true`). This looks like an off-by-mapping quirk
    but is what the released code executes; we replicate it exactly.
(4) UpdateCA fitness restoration on removal uses the removed solution's OWN
    column scale C(x) for the whole row (`exp(-I(x,:)/C(x)/0.05)`), not the
    per-column C(j) used when building F. Replicated exactly (this matches the
    PlatEMO Two_Arch2 lineage of the code).
(5) MATLAB `norm(v, p)` with p = 1/M (< 1) computes (sum |v|^p)^(1/p); ported as
    such.
(6) MATLAB `std` normalizes by N-1; numpy ddof=1 is used in Shape_Estimate.
(7) Small epsilon guards are added where MATLAB would produce Inf/NaN on a
    degenerate normalization range (Zmax == Zmin on some axis); these never
    change behaviour on non-degenerate populations.
(8) OperatorGA is ported with PlatEMO's exact semantics: SBX applied per pair
    with prob proC, per-variable exchange prob 0.5, eta=disC; polynomial
    mutation with PER-VARIABLE probability proM/D, eta=disM. The two calls are
    {proC=1, disC=20, proM=0} (crossover-only) and {proM=1, disM=20, proC=0}
    (mutation-only), as in MaOEAHAP.m.

Verification: this port was checked by line-by-line correspondence with the
MATLAB source and by component-level unit tests. Unlike the SDR port, it has
not been cross-validated numerically against a running PlatEMO instance.

Seeding: all randomness is drawn from one generator created from ``seed``
(mating, both variation operators and the random truncation in UpdateDA).
"""

import numpy as np
from scipy.spatial.distance import cdist

from pymoo.core.algorithm import Algorithm
from pymoo.core.population import Population
from pymoo.core.initialization import Initialization
from pymoo.operators.sampling.rnd import FloatRandomSampling
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting
from pymoo.operators.survival.rank_and_crowding.metrics import get_crowding_function
from pymoo.util.display.multi import MultiObjectiveOutput


# =====================================================================
# PlatEMO OperatorGA (real-coded), ported exactly
# =====================================================================
def operator_ga(X_parent, xl, xu, proC, disC, proM, disM, rng):
    """PlatEMO OperatorGA for real encodings.

    SBX: per-pair applied with prob proC; per-variable exchange prob 0.5;
         spread factor eta = disC. Parent list is split in half; each pair yields
         two children, so len(offspring) == 2*floor(N/2).
    PM : PER-VARIABLE mutation probability proM/D, eta = disM, applied to all
         children after clipping into bounds.
    """
    N, D = X_parent.shape
    n_pair = N // 2
    P1 = X_parent[:n_pair]
    P2 = X_parent[n_pair:2 * n_pair]

    # ---- simulated binary crossover ----
    mu = rng.random((n_pair, D))
    beta = np.empty((n_pair, D))
    le = mu <= 0.5
    beta[le] = (2.0 * mu[le]) ** (1.0 / (disC + 1.0))
    beta[~le] = (2.0 - 2.0 * mu[~le]) ** (-1.0 / (disC + 1.0))
    beta = beta * ((-1.0) ** rng.integers(0, 2, size=(n_pair, D)))
    beta[rng.random((n_pair, D)) < 0.5] = 1.0                       # 50% per-var exchange
    beta[np.repeat(rng.random((n_pair, 1)) > proC, D, axis=1)] = 1.0  # per-pair proC
    off1 = (P1 + P2) / 2.0 + beta * (P1 - P2) / 2.0
    off2 = (P1 + P2) / 2.0 - beta * (P1 - P2) / 2.0
    Off = np.vstack([off1, off2])

    # ---- polynomial mutation (per-variable prob proM/D) ----
    n_off = Off.shape[0]
    L = np.broadcast_to(xl, (n_off, D))
    U = np.broadcast_to(xu, (n_off, D))
    Off = np.minimum(np.maximum(Off, L), U)
    site = rng.random((n_off, D)) < (proM / D)
    mu = rng.random((n_off, D))
    span = U - L
    t = site & (mu <= 0.5)
    if np.any(t):
        Off[t] = Off[t] + span[t] * (
            (2.0 * mu[t] + (1.0 - 2.0 * mu[t]) *
             (1.0 - (Off[t] - L[t]) / span[t]) ** (disM + 1.0)) ** (1.0 / (disM + 1.0)) - 1.0)
    t = site & (mu > 0.5)
    if np.any(t):
        Off[t] = Off[t] + span[t] * (
            1.0 - (2.0 * (1.0 - mu[t]) + 2.0 * (mu[t] - 0.5) *
                   (1.0 - (U[t] - Off[t]) / span[t]) ** (disM + 1.0)) ** (1.0 / (disM + 1.0)))
    return np.minimum(np.maximum(Off, L), U)


# =====================================================================
# AssociateAngle.m
# =====================================================================
def associate_angle(PopObj):
    """Harmonically weighted sum of each solution's M smallest angles to others.
    Larger value = more angularly isolated."""
    N, M = PopObj.shape
    cosine = 1.0 - cdist(PopObj, PopObj, metric="cosine")
    np.fill_diagonal(cosine, 0.0)                       # MATLAB zeroes the diagonal
    cosine = np.clip(cosine, -1.0, 1.0)
    ang = np.arccos(cosine)
    ang_sorted = np.sort(ang, axis=1)
    K = min(M, N)                                       # guard: fewer solutions than M
    weights = 1.0 / np.arange(1, K + 1)
    return ang_sorted[:, :K] @ weights                  # sum_j Angle(i,j)/j


# =====================================================================
# NDQSort.m  (first front only, i.e. the nSort=1 call used by UpdateDA)
# =====================================================================
def ndq_first_front(PopObj):
    """Boolean mask of the (angular) first front, replicating NDQSort(objs, 1).

    unique-rows lexicographic dedup; then:
      * M < 3 or N_unique < 500  -> ENS_SS with the ANGULAR dominance rule
        (a solution is excluded only if Pareto-dominated by an assigned solution
        AND its harmonic angle measure is smaller);
      * otherwise                -> T_ENS in MATLAB, which is a standard
        non-dominated sort (no angle); replaced by pymoo's standard front, which
        is output-equivalent.
    """
    U, inverse = np.unique(PopObj, axis=0, return_inverse=True)   # lex-sorted
    Nu, M = U.shape

    if M < 3 or Nu < 500:
        front1 = _ens_ss_angular_first_front(U)
    else:
        nd = NonDominatedSorting().do(U, only_non_dominated_front=True)
        front1 = np.zeros(Nu, dtype=bool)
        front1[nd] = True

    return front1[inverse]


def _ens_ss_angular_first_front(U):
    """Single ENS_SS pass (MaxFNo = 1) with the angular dominance modification,
    verbatim from NDQSort.m's ENS_SS."""
    Nu, M = U.shape
    angle = associate_angle(U)
    in_front = np.zeros(Nu, dtype=bool)
    for i in range(Nu):                                  # lexicographic order
        dominated = False
        for j in range(i - 1, -1, -1):
            if in_front[j]:
                # weak dominance check on objectives 2..M (obj1 by lex order)
                if np.all(U[i, 1:] >= U[j, 1:]):
                    dominated = angle[i] < angle[j]      # the angular rule
                else:
                    dominated = False
                if dominated or M == 2:
                    break
        if not dominated:
            in_front[i] = True
    return in_front


# =====================================================================
# UpdateCA.m  (epsilon-indicator truncation, Two_Arch2 lineage)
# =====================================================================
def update_ca(CA, New, max_size):
    merged = New if CA is None else Population.merge(CA, New)
    N = len(merged)
    if N <= max_size:
        return merged

    F = merged.get("F").astype(float)
    fmin, fmax = F.min(axis=0), F.max(axis=0)
    rng_ = np.maximum(fmax - fmin, 1e-12)                # eps guard (note 7)
    Fn = (F - fmin) / rng_

    # epsilon indicator I(i,j) = max_m (Fn[i,m] - Fn[j,m])
    I = np.max(Fn[:, None, :] - Fn[None, :, :], axis=2)
    C = np.max(np.abs(I), axis=0)                        # per-column scale
    C = np.maximum(C, 1e-12)
    Fit = np.sum(-np.exp(-I / C[None, :] / 0.05), axis=0) + 1.0

    choose = list(range(N))
    while len(choose) > max_size:
        sub = np.asarray(choose)
        x_local = int(np.argmin(Fit[sub]))
        x = int(sub[x_local])
        # restoration uses the REMOVED solution's own scale C(x) (note 4)
        Fit = Fit + np.exp(-I[x, :] / C[x] / 0.05)
        del choose[x_local]
    return merged[np.asarray(choose)]


# =====================================================================
# Shape_Estimate.m
# =====================================================================
def shape_estimate(F, n_sort, z, znad):
    fronts = NonDominatedSorting().do(F, n_stop_if_ranked=n_sort)
    F1 = F[fronts[0]]
    n1 = F1.shape[0]
    span = np.maximum(znad - z, 1e-12)
    Fn = (F1 - z) / span
    Fn = np.maximum(Fn, 0.0)                             # numeric guard for ^cp
    CP = np.arange(0.5, 2.0 + 1e-9, 0.1)
    Vp = np.full(CP.shape[0], np.inf)
    for i, cp in enumerate(CP):
        Gp = np.sum(Fn ** cp, axis=1) ** (1.0 / cp)
        temp = np.sort(Gp)
        q1 = temp[max(int(np.fix(n1 * 0.25)) - 1, 0)]    # MATLAB 1-based temp(max(fix(...),1))
        q3 = temp[max(int(np.fix(n1 * 0.75)) - 1, 0)]
        hi = q3 + 1.5 * (q3 - q1)
        Gp = Gp[Gp <= hi]
        if Gp.size >= 2 and Gp.max() > 0:
            Vp[i] = np.std(Gp / Gp.max(), ddof=1)        # MATLAB std: N-1 (note 6)
    return float(CP[int(np.argmin(Vp))])


def _lp_norm(v, p):
    """MATLAB norm(v, p) for vectors, valid for 0 < p < 1: (sum |v|^p)^(1/p)."""
    return np.sum(np.abs(v) ** p) ** (1.0 / p)


def _dapt(F, z, Lp, p):
    """DAPT_i = || f_i' - proj_Lp(f_i') ||_p  with f' = F - z + 1e-6."""
    M = F.shape[1]
    P = F - z[None, :] + 1e-6
    denom = np.sum(P ** Lp, axis=1) ** (1.0 / Lp)
    tran = P / denom[:, None]
    return np.array([_lp_norm(P[i] - tran[i], p) for i in range(P.shape[0])])


# =====================================================================
# flog.m
# =====================================================================
def flog(DA, n_sort, p):
    F = DA.get("F").astype(float)
    z, znad = F.min(axis=0), F.max(axis=0)
    Lp = shape_estimate(F, n_sort, z, znad)
    dapt = _dapt(F, z, Lp, p)
    return 1 if np.all(dapt < 1.0) else 0


# =====================================================================
# UpdateDA.m
# =====================================================================
def update_da(DA, New, max_size, p, fe, max_fe, k, rng=None):
    rng = np.random if rng is None else rng
    merged = New if DA is None else Population.merge(DA, New)
    F_all = merged.get("F").astype(float)
    nd_mask = ndq_first_front(F_all)                     # angular first front
    merged = merged[nd_mask]
    N = len(merged)
    if N <= max_size:
        return merged

    F = merged.get("F").astype(float)
    zmin, zmax = F.min(axis=0), F.max(axis=0)
    span = np.maximum(zmax - zmin, 1e-12)                # eps guard (note 7)
    Fn = (F - zmin) / span
    M = F.shape[1]
    choose = np.zeros(N, dtype=bool)

    # ---- extreme solutions via masked ASF (replicating the subset-index quirk,
    #      note 3: the argmin is computed on the not-chosen subset but applied as
    #      a GLOBAL index, exactly as the MATLAB does) ----
    W = np.full((M, M), 1e-6) + np.eye(M)
    for i in range(M):
        rem_mask = ~choose
        sub = Fn[rem_mask]
        asf = np.max(sub / W[i][None, :], axis=1) + 0.1 * sub[:, i] / 1e-6
        idx_in_subset = int(np.argmin(asf))
        choose[idx_in_subset] = True                     # subset index used globally

    if int(choose.sum()) > max_size:
        chosen = np.where(choose)[0]
        drop = rng.permutation(chosen.shape[0])[:int(choose.sum()) - max_size]
        choose[chosen[drop]] = False
    elif int(choose.sum()) < max_size:
        cosine = 1.0 - cdist(Fn, Fn, metric="cosine")
        cosine = np.clip(cosine, -1.0, 1.0)
        angle = np.arccos(cosine)
        Lp = shape_estimate(F, max_size, zmin, zmax)
        dapt = _dapt(F, zmin, Lp, p)

        ratio = 0.0 if max_fe is None or max_fe <= 0 else (fe ** 2) / (max_fe ** 2)
        while int(choose.sum()) < max_size:
            sel = np.where(choose)[0]
            rem = np.where(~choose)[0]
            min_ang = np.min(angle[np.ix_(rem, sel)], axis=1)
            if k == 0:
                bb = min_ang * (1.0 + 2.0 * ratio)
                cc = 1.0 / np.maximum(dapt[rem] * (2.0 - ratio), 1e-12)
                fitness = bb * cc
                choose[rem[int(np.argmax(fitness))]] = True
            else:
                choose[rem[int(np.argmax(min_ang))]] = True

    return merged[choose]


# =====================================================================
# MatingSelection.m + CrowdDistance.m
# =====================================================================
def mating_selection(CA, DA, N, rng):
    F_ca = CA.get("F").astype(float)
    n_ca, n_da = len(CA), len(DA)
    half = int(np.ceil(N / 2))

    # -- ParentC: CA binary Pareto tournament (half) + DA random (half) --
    p1 = rng.integers(0, n_ca, size=half)
    p2 = rng.integers(0, n_ca, size=half)
    dom = (np.any(F_ca[p1] < F_ca[p2], axis=1).astype(int)
           - np.any(F_ca[p1] > F_ca[p2], axis=1).astype(int))
    winners = np.where(dom == 1, p1, p2)
    parentC_X = np.vstack([CA[winners].get("X"),
                           DA[rng.integers(0, n_da, size=half)].get("X")])

    # -- ParentM: CA crowding-distance tournament (CrowdDistance.m) --
    fronts = NonDominatedSorting().do(F_ca, n_stop_if_ranked=min(N, n_ca))
    crowd = np.zeros(n_ca)
    cd = get_crowding_function("cd")
    for fr in fronts:
        if len(fr):
            crowd[fr] = cd.do(F_ca[fr])
    pool_range = min(N, n_ca)                            # MATLAB uses N literally
    pool = np.empty(N, dtype=int)
    for i in range(N):
        a, b = rng.permutation(pool_range)[:2]
        if crowd[a] < crowd[b]:
            pool[i] = b
        elif crowd[a] > crowd[b]:
            pool[i] = a
        else:
            pool[i] = a if rng.random() < 0.5 else b
    parentM_X = CA[pool].get("X")
    return parentC_X, parentM_X


# =====================================================================
# The algorithm
# =====================================================================
class MaOEA_HAP(Algorithm):
    """MaOEA-HAP (Yue et al., SWEVO 2026), ported from the authors' PlatEMO code.

    CA/DA dual-archive; reported population is the DA archive. Evaluates ~2N
    offspring per generation (SBX-only batch + PM-only batch), so run it under an
    n_eval budget for parity with single-batch algorithms.

    Constructor mirrors the other baselines: `ref_dirs` is accepted & ignored
    (the algorithm is archive-based, not decomposition-based).
    """

    def __init__(self, pop_size=100, ref_dirs=None, seed=None,
                 output=MultiObjectiveOutput(), **kwargs):
        super().__init__(output=output, **kwargs)
        self.pop_size = pop_size
        self.CAsize = pop_size
        self.initialization = Initialization(FloatRandomSampling())
        self._seed = seed
        self._rng = np.random.default_rng(seed)
        self.CA = None
        self.DA = None
        self.k = 0
        self.p = None

    def _setup(self, problem, **kwargs):
        self.p = 1.0 / problem.n_obj
        if self._seed is None and getattr(self, "seed", None) is not None:
            self._rng = np.random.default_rng(self.seed)     # seed given to minimize

    def _initialize_infill(self):
        # pymoo >= 0.6.2 draws the initial sample from the algorithm's random_state;
        # without it the sampler would create an unseeded generator.
        rs = getattr(self, "random_state", None)
        kw = {} if rs is None else {"random_state": rs}
        return self.initialization.do(self.problem, self.pop_size, algorithm=self, **kw)

    def _initialize_advance(self, infills=None, **kwargs):
        self.CA = update_ca(None, infills, self.CAsize)
        # initial UpdateDA([],Pop,N): ND filter runs, size check passes
        self.DA = update_da(None, infills, self.pop_size, self.p,
                            fe=self.evaluator.n_eval, max_fe=self._max_fe(), k=self.k,
                            rng=self._rng)
        self.pop = self.DA

    def _max_fe(self):
        mf = getattr(self.termination, "n_max_evals", None)
        if mf:
            return mf
        n_gen = getattr(self.termination, "n_max_gen", None)
        return (n_gen * 2 * self.pop_size) if n_gen else None

    def _infill(self):
        parentC_X, parentM_X = mating_selection(self.CA, self.DA,
                                                self.pop_size, self._rng)
        xl, xu = self.problem.xl, self.problem.xu
        # OperatorGA(Problem, ParentC, {1,20,0,0}): SBX-only
        offC = operator_ga(parentC_X, xl, xu, proC=1.0, disC=20.0,
                           proM=0.0, disM=0.0, rng=self._rng)
        # OperatorGA(Problem, ParentM, {0,0,1,20}): mutation-only
        offM = operator_ga(parentM_X, xl, xu, proC=0.0, disC=0.0,
                           proM=1.0, disM=20.0, rng=self._rng)
        return Population.new(X=np.vstack([offC, offM]))

    def _advance(self, infills=None, **kwargs):
        self.CA = update_ca(self.CA, infills, self.CAsize)
        self.DA = update_da(self.DA, infills, self.pop_size, self.p,
                            fe=self.evaluator.n_eval, max_fe=self._max_fe(),
                            k=self.k, rng=self._rng)
        self.k = flog(self.DA, self.pop_size, self.p)
        self.pop = self.DA


def make_maoea_hap(pop_size, ref_dirs=None, seed=None, **kwargs):
    """Factory mirroring the style of the other baseline constructors.

    ``seed`` seeds the generator used for mating, variation and the random
    truncation of UpdateDA. Pass the same seed as to ``minimize`` for a run that
    is reproducible bit for bit.
    """
    return MaOEA_HAP(pop_size=pop_size, seed=seed, **kwargs)
