# -*- coding: utf-8 -*-
"""Test problems: an adapter for the DTLZ and WFG problems of pymoo, and an
implementation of MaF1, MaF2, MaF3, MaF6 and MaF7, which pymoo does not provide.

Common interface
    n_var, M, lo, hi, evaluate(X) -> F
    pareto_front(n_ref) -> reference front for IGD+, or None if unavailable
"""
from __future__ import annotations

import numpy as np


# ------------------------------------------------------------------ reference fronts
def simplex_lattice(M, H):
    """Das-Dennis simplex-lattice points."""
    def rec(prefix, left, slots):
        if slots == 1:
            yield prefix + [left]
            return
        for v in range(left + 1):
            yield from rec(prefix + [v], left - v, slots - 1)
    return np.array(list(rec([], H, M)), dtype=float) / H


def _H_for(M, target=1000):
    from math import comb
    H = 1
    while comb(H + M - 1, M - 1) < target and H < 60:
        H += 1
    return H


def unit_sphere_front(M, target=1000):
    W = simplex_lattice(M, _H_for(M, target))
    n = np.linalg.norm(W, axis=1, keepdims=True)
    n[n == 0] = 1.0
    return W / n


def unit_simplex_front(M, target=1000):
    return simplex_lattice(M, _H_for(M, target))


# ------------------------------------------------------------------ pymoo problems
class PymooProblem:
    """A pymoo problem such as 'dtlz2' or 'wfg4'."""

    def __init__(self, name, M, n_var=None):
        from pymoo.problems import get_problem
        self.name = name
        self.M = int(M)
        if name.startswith("wfg"):
            k = 2 * (self.M - 1)
            n_var = n_var or (k + 10)
            self._p = get_problem(name, n_var=n_var, n_obj=self.M, k=k)
        else:
            kwargs = {"n_obj": self.M}
            if n_var:
                kwargs["n_var"] = n_var
            self._p = get_problem(name, **kwargs)
        self.n_var = self._p.n_var
        self.lo = np.array(self._p.xl, dtype=float)
        self.hi = np.array(self._p.xu, dtype=float)

    def evaluate(self, X):
        return self._p.evaluate(np.atleast_2d(np.asarray(X, float)),
                                return_values_of=["F"])

    # WFG fronts are scaled by 2j. WFG3 is a degenerate curve, WFG4 to WFG9
    # are concave spheres, and WFG1 and WFG2 are taken from pymoo.
    _WFG_SHAPE = {"wfg1": "mixed", "wfg2": "disconnected", "wfg3": "degenerate"}

    def _wfg3_front(self, M, n_ref):
        """Degenerate Pareto front of WFG3.

        The position variable x_1 ranges over [0, 1] and x_2 to x_{M-1} are
        fixed at 1/2 in the linear shape function, scaled by 2j. The result is
        a curve that agrees point by point with WFG3.GetOptimum of PlatEMO.
        """
        t = np.linspace(0.0, 1.0, n_ref)
        X = np.empty((n_ref, M - 1))
        X[:, 0] = t
        X[:, 1:] = 0.5
        h = np.empty((n_ref, M))
        h[:, 0] = np.prod(X, axis=1)
        for m in range(1, M - 1):
            h[:, m] = np.prod(X[:, : M - 1 - m], axis=1) * (1.0 - X[:, M - 1 - m])
        h[:, M - 1] = 1.0 - X[:, 0]
        return h * (2.0 * np.arange(1, M + 1))

    def pareto_front(self, n_ref=1000):
        """Reference front.

        WFG3 to WFG9 use the analytic fronts at every number of objectives
        (checked point by point against pymoo at M=5). Other problems use the
        front of pymoo. The result is cached on the instance per (name, M,
        n_ref), so repeated calls return the same point set.
        """
        M = self.M
        key = (self.name, M, int(n_ref))
        cache = getattr(self, "_pf_cache", None)
        if cache is None:
            cache = self._pf_cache = {}
        if key in cache:
            return cache[key]

        pf = None
        if self.name.startswith("wfg"):
            shape = self._WFG_SHAPE.get(self.name, "concave")
            scale = 2.0 * np.arange(1, M + 1)
            if shape == "degenerate":
                pf = self._wfg3_front(M, n_ref)
            elif shape == "concave":
                pf = unit_sphere_front(M, n_ref) * scale
        if pf is None:
            try:
                ref = simplex_lattice(self.M, _H_for(self.M, n_ref))
                got = self._p.pareto_front(ref_dirs=ref)
                pf = None if got is None else np.asarray(got, dtype=float)
            except Exception:
                try:
                    got = self._p.pareto_front()
                    pf = None if got is None else np.asarray(got, dtype=float)
                except Exception:
                    pf = None
        cache[key] = pf
        return pf


# ------------------------------------------------------------------ MaF problems
class MaFProblem:
    """MaF1, MaF2, MaF3, MaF6 and MaF7 as defined by Cheng et al. (2017).

    MaF1 modified inverted DTLZ1 (linear front)
    MaF2 DTLZ2BZ (concave front, grouped variables)
    MaF3 convex DTLZ3 (multimodal, convex front)
    MaF6 DTLZ5(I,M) (degenerate front of dimension I = 2)
    MaF7 DTLZ7 (disconnected front)
    """

    def __init__(self, name, M, k=None):
        self.name = name.lower()
        self.M = int(M)
        default_k = {"maf1": 10, "maf2": 10, "maf3": 10, "maf6": 10, "maf7": 20}
        self.k = int(k or default_k[self.name])
        self.n_var = self.M - 1 + self.k
        self.lo = np.zeros(self.n_var)
        self.hi = np.ones(self.n_var)
        self.I = 2  # dimension of the degenerate MaF6 front

    # -------------------------------------------------- distance functions g
    def _g_sphere(self, Xm):
        return np.sum((Xm - 0.5) ** 2, axis=1)

    def _g_rastrigin(self, Xm):
        return 100 * (Xm.shape[1] + np.sum(
            (Xm - 0.5) ** 2 - np.cos(20 * np.pi * (Xm - 0.5)), axis=1))

    def evaluate(self, X):
        X = np.atleast_2d(np.asarray(X, dtype=float))
        M, k = self.M, self.k
        Xf, Xm = X[:, : M - 1], X[:, M - 1:]
        n = X.shape[0]

        if self.name == "maf1":
            g = self._g_sphere(Xm)
            F = np.empty((n, M))
            for m in range(M):
                v = np.ones(n)
                for j in range(M - 1 - m):
                    v = v * Xf[:, j]
                if m > 0:
                    v = v * (1 - Xf[:, M - 1 - m])
                F[:, m] = (1 - v) * (1 + g)
            return F

        if self.name == "maf2":
            F = np.ones((n, M))
            c = M - 1
            seg = max(k // M, 1)
            thetas = np.empty((n, M - 1))
            for j in range(M - 1):
                thetas[:, j] = np.pi / 2 * (Xf[:, j] / 2 + 0.25)
            for m in range(M):
                lo_i = c + m * seg
                hi_i = c + (m + 1) * seg if m < M - 1 else X.shape[1]
                sub = X[:, lo_i:hi_i]
                g = (np.sum((sub / 2 + 0.25 - 0.5) ** 2, axis=1)
                     if sub.size else np.zeros(n))
                v = 1.0 + g
                for j in range(M - 1 - m):
                    v = v * np.cos(thetas[:, j])
                if m > 0:
                    v = v * np.sin(thetas[:, M - 1 - m])
                F[:, m] = v
            return F

        if self.name == "maf3":
            g = self._g_rastrigin(Xm)
            F = np.empty((n, M))
            for m in range(M):
                v = 1.0 + g
                for j in range(M - 1 - m):
                    v = v * np.cos(0.5 * np.pi * Xf[:, j])
                if m > 0:
                    v = v * np.sin(0.5 * np.pi * Xf[:, M - 1 - m])
                F[:, m] = v
            F[:, :-1] = F[:, :-1] ** 4
            F[:, -1] = F[:, -1] ** 2
            return F

        if self.name == "maf6":
            g = self._g_sphere(Xm)
            T = Xf.copy()
            for j in range(self.I - 1, M - 1):
                T[:, j] = (1 + 2 * g * Xf[:, j]) / (2 * (1 + g))
            F = np.empty((n, M))
            for m in range(M):
                v = 1.0 + 100 * g
                for j in range(M - 1 - m):
                    v = v * np.cos(0.5 * np.pi * T[:, j])
                if m > 0:
                    v = v * np.sin(0.5 * np.pi * T[:, M - 1 - m])
                F[:, m] = v
            return F

        if self.name == "maf7":
            g = 1 + 9 * np.mean(Xm, axis=1)
            F = np.empty((n, M))
            F[:, : M - 1] = Xf
            h = M - np.sum(Xf / (1 + g[:, None])
                           * (1 + np.sin(3 * np.pi * Xf)), axis=1)
            F[:, M - 1] = (1 + g) * h
            return F

        raise ValueError(self.name)

    def pareto_front(self, n_ref=1000):
        M = self.M
        if self.name == "maf1":
            return 1.0 - unit_simplex_front(M, n_ref)
        if self.name in ("maf2",):
            return unit_sphere_front(M, n_ref)
        if self.name == "maf3":
            S = unit_sphere_front(M, n_ref)
            P = S.copy()
            P[:, :-1] = P[:, :-1] ** 4
            P[:, -1] = P[:, -1] ** 2
            return P
        if self.name == "maf6":
            S = unit_sphere_front(M, n_ref)
            # degenerate front of dimension I = 2, spanned by the first two angles
            t = np.linspace(0, 1, int(np.sqrt(n_ref)) + 1)
            a, b = np.meshgrid(t, t)
            th1 = 0.5 * np.pi * a.ravel()
            th2 = 0.5 * np.pi * b.ravel()
            P = np.empty((len(th1), M))
            for m in range(M):
                v = np.ones(len(th1))
                angles = [th1, th2] + [np.full(len(th1), 0.25 * np.pi)] * (M - 3)
                for j in range(M - 1 - m):
                    v = v * np.cos(angles[j])
                if m > 0:
                    v = v * np.sin(angles[M - 1 - m])
                P[:, m] = v
            return P
        if self.name == "maf7":
            # The disconnected front is sampled. Nondominance is filtered in
            # blocks first, since a full pairwise comparison of the sample
            # needs more than 8 GB at M >= 10.
            rng = np.random.default_rng(0)
            n_sample = min(n_ref * 8, 8000)
            Xf = rng.random((n_sample, M - 1))
            Xm = np.zeros((n_sample, self.k))
            F = self.evaluate(np.hstack([Xf, Xm]))
            keep = []
            block = 1000
            for i in range(0, len(F), block):
                B = F[i: i + block]
                le = np.all(B[:, None, :] <= B[None, :, :], axis=2)
                lt = np.any(B[:, None, :] < B[None, :, :], axis=2)
                keep.append(B[~(le & lt).any(axis=0)])
            G = np.vstack(keep)
            if len(G) > 4000:                     # thin before the final filter
                G = G[rng.choice(len(G), 4000, replace=False)]
            le = np.all(G[:, None, :] <= G[None, :, :], axis=2)
            lt = np.any(G[:, None, :] < G[None, :, :], axis=2)
            return G[~(le & lt).any(axis=0)]
        return None


# ------------------------------------------------------------------ factory
MAF_NAMES = ["maf1", "maf2", "maf3", "maf6", "maf7"]
WFG_NAMES = ["wfg1", "wfg2", "wfg3", "wfg4", "wfg5", "wfg6", "wfg7", "wfg8", "wfg9"]
DTLZ_NAMES = ["dtlz1", "dtlz2", "dtlz3", "dtlz4", "dtlz5", "dtlz6", "dtlz7"]


def get_problem(name, M, **kw):
    name = name.lower()
    if name in MAF_NAMES:
        return MaFProblem(name, M, **kw)
    return PymooProblem(name, M, **kw)
